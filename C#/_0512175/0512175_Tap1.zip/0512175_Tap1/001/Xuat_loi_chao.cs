using System;
class Xuat_thong_bao
{
    public static void Main()
    {
        String Thong_bao;
        Thong_bao = "Xin chao \n";
        Thong_bao = Thong_bao + "Day la chuong trinh C# dau tien cua toi";
        Console.Write(Thong_bao);
        Console.ReadLine();
    }
}