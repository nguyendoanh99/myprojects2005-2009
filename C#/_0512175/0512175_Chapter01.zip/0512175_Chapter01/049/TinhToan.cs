using System;

public class TinhToan
{
	public static int tim(int n)
	{
		for (;n>=10;n/=10);
		return n;
	}
}
