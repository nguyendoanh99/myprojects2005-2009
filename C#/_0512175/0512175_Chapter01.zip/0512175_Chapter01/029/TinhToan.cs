using System;

public class TinhToan
{
	public static int tim(int k)
	{
		for (;k%2==0;k=k/2);
		return k;
	}
}
