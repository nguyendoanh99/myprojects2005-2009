using System;

class Program
{
	static void Main(string[] args)
	{			
		do
		{
			int n;
			n=SoNguyen.NhapSoNguyenDuong("Nhap n = ");			
			if (TinhToan.ktnt(n))
				Console.Write(n+" la so nguyen to");
			else
				Console.Write(n+" khong la so nguyen to");			
		} while (SoNguyen.NhapSoNguyen("\nTiep tuc (1.Tiep, 0.Khong) ? ")!=0);
	}
}
