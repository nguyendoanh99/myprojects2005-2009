using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Do_an_do_hoa
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            frm_Man_hinh_chinh form = new frm_Man_hinh_chinh();

            while (!form.IsDisposed)
            {
                form.Invalidate();
                Application.DoEvents();
            }

            form.Dispose();


            /*Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frm_Man_hinh_chinh());*/
        }
    }
}