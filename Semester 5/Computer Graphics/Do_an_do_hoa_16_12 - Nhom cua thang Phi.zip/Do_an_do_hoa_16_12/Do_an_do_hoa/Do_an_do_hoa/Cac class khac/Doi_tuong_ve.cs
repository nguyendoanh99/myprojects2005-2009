﻿using System;
using System.Collections.Generic;
using System.Text;
using CsGL.OpenGL;
namespace Do_an_do_hoa
{
    public class Doi_tuong_ve
    {
        private int _loai;      
        private float[] _mau;
        private float[] _ty_le;
        private float[] _toa_do;
        private float[] _goc_quay;        
        private bool _su_dung_texture;        
        private CTexture _texture;
        private bool _su_dung_trong_suot;
        

        #region "Property"
        public float[] Mau
        {
            get { return _mau; }
            set { _mau = value; }
        }        

        public CTexture Texture
        {
            get { return _texture; }
            set { _texture = value; }
        }

        
        public float[] Ty_le
        {
            get { return _ty_le; }
            set { _ty_le = value; }
        }
        public float[] Goc_quay
        {
            get { return _goc_quay; }
            set { _goc_quay = value; }
        }
        public float[] Toa_do
        {
            get { return _toa_do; }
            set { _toa_do = value; }
        }
       

        public bool Su_dung_texture
        {
            get { return _su_dung_texture; }
            set { _su_dung_texture = value; }
        }
        public int Loai
        {
            get { return _loai; }
            set { _loai = value; }
        }
        public bool Su_dung_trong_suot
        {
            get { return _su_dung_trong_suot; }
            set { _su_dung_trong_suot = value; }
        } 
        #endregion

        public Doi_tuong_ve()
        {
            Loai = 1;
            Mau = new float[3];
            Ty_le = new float[3];
            Goc_quay = new float[3];
            Toa_do = new float[3];            
            Mau[0] = Mau[1] = Mau[2] = 1.0f;
            Ty_le[0] = Ty_le[1] = Ty_le[2] = 1;
                
            Texture = new CTexture();
            Su_dung_texture = false;
            Su_dung_trong_suot = false;
        }        
        public virtual void Ve(GLUquadric quadric)
        {
            ///GL.glLoadIdentity();
            GL.glPushMatrix();
            GL.glColor3f(Mau[0], Mau[1], Mau[2]);
            
            GL.glTranslatef(Toa_do[0], Toa_do[1], Toa_do[2]);        
            
            
            GL.glRotatef(Goc_quay[0], 1, 0, 0); 
            GL.glRotatef(Goc_quay[1], 0, 1, 0);
            GL.glRotatef(Goc_quay[2], 0, 0, 1);           
            GL.glScalef(Ty_le[0], Ty_le[1], Ty_le[2]);
            //GL.glGetFloatv(GL.GL_MODELVIEW_MATRIX, Doi_tuong_ve.Ma_tran_hien_tai);
            if (Su_dung_texture)
            {
                GL.glEnable(GL.GL_TEXTURE_2D);
                GL.gluQuadricTexture(quadric, 1);
                if (Texture.Thay_doi_texture)
                {
                    Texture.Load();
                    Texture.Thay_doi_texture = false;
                }
            }
            if (Su_dung_trong_suot)
                Hien_thi_trong_suot();
        }
        #region "Trong suot"
        public static void Hien_thi_trong_suot()
        {
            GL.glEnable(GL.GL_BLEND);													// Turn Blending On
            GL.glDisable(GL.GL_DEPTH_TEST);
            GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE);
        }
        public static void Ket_thuc_trong_suot()
        {
            GL.glDisable(GL.GL_BLEND);
            GL.glEnable(GL.GL_DEPTH_TEST);
        }

        #endregion
        #region "Cac ham ve"
        public static void Ve_truc_toa_do_oxyx()
        {
            GL.glPushMatrix();          
            GL.glDisable(GL.GL_TEXTURE_2D);            
            GL.glColor3f(1, 1, 1);
            GL.glTranslatef(0, 0,0);
            GL.glBegin(GL.GL_LINES);            
            GL.glVertex3f(30, 0, 0); GL.glVertex3f(-30, 0, 0);
            GL.glVertex3f(0, 30, 0); GL.glVertex3f(0, -30, 0);
            GL.glVertex3f(0, 0, 30); GL.glVertex3f(0, 0, -30);
            GL.glEnd();           
            int[] a = { 0, 0, 0 };
            for (int i = 0; i < 3; i++)
            {
                a[i] = 1;
                for (int j = 0; j < 21; j++)
                {

                    GL.glPushMatrix();
                    GL.glTranslatef((-10 + j + 1) * a[0], (-10 + j + 1) * a[1], (-10 + j + 1) * a[2]);
                    GL.glColor3f(0, 0, 1);
                    GL.glutSolidCube(0.05);
                    GL.glPopMatrix();
                }
                a = new int[3];
            }
            GL.glPopMatrix();
        }
        public static void Ve_luoi_nen()
        {
            GL.glDisable(GL.GL_LIGHTING);
            GL.glPushMatrix();
            float fExtent = 40.0f;
            float fStep = 1.0f;
            float y = -3f;
            float iLine;
            GL.glBegin(GL.GL_LINES);
            GL.glColor3f(0.0f, 0.3f, 0.0f);
            for (iLine = -fExtent; iLine <= fExtent; iLine += fStep)
            {
                GL.glVertex3f(iLine, y, fExtent); // Draw Z lines
                GL.glVertex3f(iLine, y, -fExtent);
                GL.glVertex3f(fExtent, y, iLine);
                GL.glVertex3f(-fExtent, y, iLine);
            }
            GL.glEnd();

            GL.glPopMatrix();
            GL.glEnable(GL.GL_LIGHTING);
        }
        public static void Ve_hinh_lap_phuong(float Ban_kinh)
        {
            if (Doi_tuong_OPENGL.Ve_khung)
                GL.glutWireCube(2.0f);
            else
            {
                GL.glBegin(GL.GL_QUADS);

                GL.glTexCoord2f(1, 0);
                GL.glVertex3f(Ban_kinh, Ban_kinh, -Ban_kinh);
                GL.glTexCoord2f(0, 0);
                GL.glVertex3f(-Ban_kinh, Ban_kinh, -Ban_kinh);
                GL.glTexCoord2f(0, 1);
                GL.glVertex3f(-Ban_kinh, Ban_kinh, Ban_kinh);
                GL.glTexCoord2f(1, 1);
                GL.glVertex3f(Ban_kinh, Ban_kinh, Ban_kinh);               

                GL.glTexCoord2f(1, 1);
                GL.glVertex3f(Ban_kinh, -Ban_kinh, Ban_kinh);
                GL.glTexCoord2f(0, 1);
                GL.glVertex3f(-Ban_kinh, -Ban_kinh, Ban_kinh);
                GL.glTexCoord2f(0, 0);
                GL.glVertex3f(-Ban_kinh, -Ban_kinh, -Ban_kinh);
                GL.glTexCoord2f(1, 0);
                GL.glVertex3f(Ban_kinh, -Ban_kinh, -Ban_kinh);

                GL.glTexCoord2f(1, 1);
                GL.glVertex3f(Ban_kinh, Ban_kinh, Ban_kinh);
                GL.glTexCoord2f(0, 1);
                GL.glVertex3f(-Ban_kinh, Ban_kinh, Ban_kinh);
                GL.glTexCoord2f(0, 0);
                GL.glVertex3f(-Ban_kinh, -Ban_kinh, Ban_kinh);
                GL.glTexCoord2f(1, 0);
                GL.glVertex3f(Ban_kinh, -Ban_kinh, Ban_kinh);

                GL.glTexCoord2f(1, 0);
                GL.glVertex3f(Ban_kinh, -Ban_kinh, -Ban_kinh);
                GL.glTexCoord2f(0, 0);
                GL.glVertex3f(-Ban_kinh, -Ban_kinh, -Ban_kinh);
                GL.glTexCoord2f(0, 1);
                GL.glVertex3f(-Ban_kinh, Ban_kinh, -Ban_kinh);
                GL.glTexCoord2f(1, 1);
                GL.glVertex3f(Ban_kinh, Ban_kinh, -Ban_kinh);


                GL.glTexCoord2f(1, 1);
                GL.glVertex3f(-Ban_kinh, Ban_kinh, Ban_kinh);
                GL.glTexCoord2f(1, 0);
                GL.glVertex3f(-Ban_kinh, Ban_kinh, -Ban_kinh);
                GL.glTexCoord2f(0, 0);
                GL.glVertex3f(-Ban_kinh, -Ban_kinh, -Ban_kinh);
                GL.glTexCoord2f(0, 1);
                GL.glVertex3f(-Ban_kinh, -Ban_kinh, Ban_kinh);

                GL.glTexCoord2f(1, 0);
                GL.glVertex3f(Ban_kinh, Ban_kinh, -Ban_kinh);
                GL.glTexCoord2f(1, 1);
                GL.glVertex3f(Ban_kinh, Ban_kinh, Ban_kinh);
                GL.glTexCoord2f(0, 1);
                GL.glVertex3f(Ban_kinh, -Ban_kinh, Ban_kinh);
                GL.glTexCoord2f(0, 0);
                GL.glVertex3f(Ban_kinh, -Ban_kinh, -Ban_kinh);
                GL.glEnd();
            }            
        }
        public static void Ve_hinh_cau(GLUquadric quadric, float Ban_kinh)
        {
            GL.gluSphere(quadric, Ban_kinh, 20, 20);  
        }
        public static void Ve_hinh_tru(GLUquadric quadric, float Ban_kinh, float Chieu_dai)
        {            
            GL.gluCylinder(quadric, Ban_kinh,Ban_kinh, Chieu_dai, 20, 20);
        }
        public static void Ve_hinh_non(GLUquadric quadric, float Ban_kinh, float Chieu_dai)
        {
            GL.gluCylinder(quadric, 0, Ban_kinh, Chieu_dai, 20, 20);
        }
        
        public static void Ve_may_bay(GLUquadric quadric)
        {

            GL.glDisable(GL.GL_CULL_FACE);

            GL.glPushMatrix();
            GL.glTranslatef(0, 0, -2.5f);
            GL.gluCylinder(quadric, .5, .5, 5, 10, 10);
            GL.glPushMatrix();
            GL.glTranslatef(0, 0, 5);
            GL.gluCylinder(quadric, 0.5, 0, 1, 10, 10);
            //ten lua 
            GL.glPushMatrix();
            GL.glTranslatef(1f, -0.25f, -2f);
            GL.gluCylinder(quadric, 0.2, 0.2, 1.5, 10, 10);

            GL.glTranslatef(0f, 0f, 1.5f);
            GL.gluCylinder(quadric, 0.2, 0, 0.4, 10, 10);
            GL.glPopMatrix();

            GL.glPushMatrix();
            GL.glTranslatef(-1f, -0.25f, -2f);
            GL.gluCylinder(quadric, 0.2, 0.2, 1.5, 10, 10);

            GL.glTranslatef(0f, 0f, 1.5f);
            GL.gluCylinder(quadric, 0.2, 0, 0.4, 10, 10);
            GL.glPopMatrix();
            //ten lua
            GL.glPopMatrix();


            GL.glPushMatrix();

            GL.glTranslatef(1.5f, 0, 3.5f);
            GL.glRotatef(30, 0, 1, 0);
            GL.glScalef(4, 0.1f, 1);
            GL.gluSphere(quadric, 0.5, 10, 10);
            GL.glPopMatrix();

            GL.glPushMatrix();
            GL.glTranslatef(-1.5f, 0, 3.5f);
            GL.glRotatef(-30, 0, 1, 0);
            GL.glScalef(4, 0.1f, 1);
            GL.gluSphere(quadric, 0.5, 10, 10);
            GL.glPopMatrix();

            GL.glPushMatrix();
            GL.glTranslatef(0, 0.0f, 0.5f);
            GL.glScalef(1.5f, 0.1f, 0.5f);
            GL.gluSphere(quadric, 1, 10, 10);
            GL.glPopMatrix();

            GL.glEnable(GL.GL_CULL_FACE);

            GL.glBegin(GL.GL_TRIANGLES);
            GL.glNormal3f(1, 0, 0);
            GL.glVertex3f(0, 1.5f, 0);
            GL.glVertex3f(0, .5f, 1);
            GL.glVertex3f(0, .5f, 0);
            GL.glNormal3f(-1, 0, 0);
            GL.glVertex3f(0, 1.5f, 0);
            GL.glVertex3f(0, .5f, 0);
            GL.glVertex3f(0, .5f, 1);
            GL.glEnd();
            GL.glDisable(GL.GL_CULL_FACE);
            //GL.glRotatef(180, 0, 1, 0);
            GL.gluDisk(quadric, 0, 0.5f, 20, 20);
            GL.glTranslatef(0, 0, -0.5f);
            GL.gluCylinder(quadric, 1f, 0.5, 0.5, 20, 20);
            GL.glPopMatrix();


        }
        
        private static void Ve_khinh_khi_cau(GLUquadric quadric)
        {
            GL.glDisable(GL.GL_CULL_FACE);
            GL.glBegin(GL.GL_LINES);

            GL.glVertex3f(0.5f, 0.5f, -0.5f); GL.glVertex3f(1f, 6, -0.5f);
            GL.glVertex3f(-0.5f, 0.5f, -0.5f); GL.glVertex3f(-1f, 6, -0.5f);
            GL.glVertex3f(-0.5f, 0.5f, 0.5f); GL.glVertex3f(-1f, 6, 0.5f);
            GL.glVertex3f(0.5f, 0.5f, 0.5f); GL.glVertex3f(1f, 6, 0.5f);
            GL.glEnd();

            GL.glPushMatrix();
            GL.glTranslatef(0, 7, 0);
            GL.glScalef(1, 2.5f, 1);
            GL.gluSphere(quadric, 2, 20, 20);

            GL.glPopMatrix();
            if (Doi_tuong_OPENGL.Ve_khung)
                GL.glutWireCube(2.0f);
            else
            {
                GL.glBegin(GL.GL_QUADS);
                GL.glVertex3f(0.5f, -0.5f, 0.5f);
                GL.glVertex3f(-0.5f, -0.5f, 0.5f);
                GL.glVertex3f(-0.5f, -0.5f, -0.5f);
                GL.glVertex3f(0.5f, -0.5f, -0.5f);


                GL.glVertex3f(0.5f, 0.5f, 0.5f);
                GL.glVertex3f(-0.5f, 0.5f, 0.5f);
                GL.glVertex3f(-0.5f, -0.5f, 0.5f);
                GL.glVertex3f(0.5f, -0.5f, 0.5f);


                GL.glVertex3f(0.5f, -0.5f, -0.5f);
                GL.glVertex3f(-0.5f, -0.5f, -0.5f);
                GL.glVertex3f(-0.5f, 0.5f, -0.5f);
                GL.glVertex3f(0.5f, 0.5f, -0.5f);


                GL.glVertex3f(-0.5f, 0.5f, 0.5f);
                GL.glVertex3f(-0.5f, 0.5f, -0.5f);
                GL.glVertex3f(-0.5f, -0.5f, -0.5f);
                GL.glVertex3f(-0.5f, -0.5f, 0.5f);


                GL.glVertex3f(0.5f, 0.5f, -0.5f);
                GL.glVertex3f(0.5f, 0.5f, 0.5f);
                GL.glVertex3f(0.5f, -0.5f, 0.5f);
                GL.glVertex3f(0.5f, -0.5f, -0.5f);
                GL.glEnd();
            }
        }
        public static void Ve_chuon_chuon(GLUquadric quadric)
        {

            GL.glDisable(GL.GL_CULL_FACE);

            GL.glPushMatrix();
            GL.glTranslatef(0, 0, -2.5f);
            GL.gluCylinder(quadric, .5, .6,1.0, 10, 10);


            GL.glPushMatrix();
            GL.glTranslatef(0, 0, 1);
            GL.gluSphere(quadric, 0.6f, 10, 10);
            GL.glPopMatrix();


            GL.glPushMatrix();
            GL.glTranslatef(0, 0, 1.3f);
            GL.gluSphere(quadric, 0.6f, 10, 10);

            GL.glPushMatrix();
            GL.glTranslatef(0, 0, -1.1f);
            GL.gluSphere(quadric, 0.55f, 10, 10);
            GL.glPopMatrix();

            GL.glPushMatrix();
            GL.glTranslatef(0, 0, -2f);
            GL.glScalef(0.6f, 0.6f,1);
            GL.gluSphere(quadric, 0.55f, 10, 10);            
            GL.glPopMatrix();

            GL.glPushMatrix();
            GL.glTranslatef(0, 0, -3f);
            GL.glScalef(0.45f, 0.45f, 1);
            GL.gluSphere(quadric, 0.55f, 10, 10);
            GL.glPopMatrix();

            GL.glPushMatrix();
            GL.glTranslatef(0, 0, -4f);
            GL.glScalef(0.3f, 0.3f, 1);
            GL.gluSphere(quadric, 0.55f, 10, 10);
            GL.glPopMatrix();

            GL.glPushMatrix();
            GL.glTranslatef(0, 0, -5f);
            GL.glScalef(0.15f, 0.15f, 1);
            GL.gluSphere(quadric, 0.55f, 10, 10);
            GL.glPopMatrix();
            //Ve mat

            GL.glPopMatrix();
            GL.glPushMatrix();
            GL.glTranslatef(-0.3f, 0.15f, 1.5f);

            GL.glutWireSphere(0.4, 10, 10);

            GL.glPopMatrix();
            GL.glPushMatrix();

            GL.glTranslatef(0.3f, 0.15f, 1.5f);

            GL.glutWireSphere(0.4, 10, 10);


            //GL.gluCylinder(quadric, 0.5, 0, 3, 10, 10);
            //ten lua 
            /*GL.glPushMatrix();
            GL.glTranslatef(1f, -0.25f, -2f);
            GL.gluCylinder(quadric, 0.2, 0.2, 1.5, 10, 10);

            GL.glTranslatef(0f, 0f, 1.5f);
            GL.gluCylinder(quadric, 0.2, 0, 0.4, 10, 10);
            GL.glPopMatrix();

            GL.glPushMatrix();
            GL.glTranslatef(-1f, -0.25f, -2f);
            GL.gluCylinder(quadric, 0.2, 0.2, 1.5, 10, 10);

            GL.glTranslatef(0f, 0f, 1.5f);
            GL.gluCylinder(quadric, 0.2, 0, 0.4, 10, 10);
            GL.glPopMatrix();*/
            //ten lua
            GL.glPopMatrix();
            GL.glPushMatrix();
            GL.glTranslatef(1.85f, 0.34f, 0.6f);
            //goc cua canh
            GL.glRotatef(15, 0, 1, 0);
            GL.glRotatef(10, 0, 0, 1);
            //do zep
            GL.glScalef(5f, 0.1f, 0.8f);
            GL.gluSphere(quadric, 0.5, 10, 10);
            GL.glPopMatrix();

            GL.glPushMatrix();
            GL.glTranslatef(1.85f, 0.34f, -0.2f);
            //goc cua canh
            GL.glRotatef(22, 0, 1, 0);
            GL.glRotatef(10, 0, 0, 1);
            //do zep
            GL.glScalef(5f, 0.1f, 0.8f);
            GL.gluSphere(quadric, 0.5, 10, 10);
            GL.glPopMatrix();

            GL.glPushMatrix();
            GL.glTranslatef(-1.85f, 0.34f, -0.2f);
            GL.glRotatef(-22, 0, 1, 0);
            GL.glRotatef(-10, 0, 0, 1);
            GL.glScalef(5, 0.1f, 0.8f);
            GL.gluSphere(quadric, 0.5, 10, 10);
            GL.glPopMatrix();

            GL.glPushMatrix();
            GL.glTranslatef(-1.85f, 0.34f, 0.6f);
            //goc cua canh
            GL.glRotatef(-15, 0, 1, 0);
            GL.glRotatef(-10, 0, 0, 1);
            //do zep
            GL.glScalef(5f, 0.1f, 0.8f);
            GL.gluSphere(quadric, 0.5, 10, 10);
            GL.glPopMatrix();
            /*GL.glPushMatrix();
            GL.glTranslatef(0, 0.0f, 0.5f);
            GL.glScalef(1.5f, 0.1f, 0.5f);            
            GL.gluSphere(quadric, 1, 10, 10);
            GL.glPopMatrix();*/

            /*GL.glEnable(GL.GL_CULL_FACE);

            GL.glBegin(GL.GL_TRIANGLES);
            GL.glNormal3f(1, 0, 0);
            GL.glVertex3f(0, 1.5f, 0);
            GL.glVertex3f(0, .5f, 1);
            GL.glVertex3f(0, .5f, 0);
            GL.glNormal3f(-1, 0, 0);
            GL.glVertex3f(0, 1.5f, 0);
            GL.glVertex3f(0, .5f, 0);
            GL.glVertex3f(0, .5f, 1);
            GL.glEnd();
            GL.glDisable(GL.GL_CULL_FACE);*/
            //GL.glRotatef(180, 0, 1, 0);
            /*GL.gluDisk(quadric, 0, 0.5f, 20, 20);
            GL.glTranslatef(0, 0, -0.5f);
            GL.gluCylinder(quadric, 1f, 0.5, 0.5, 20, 20);*/
            GL.glPopMatrix();


        }
        
        #endregion
        public static float[] Ma_tran_hien_tai = new float[16];

    }
    public class Hinh_lap_phuong : Doi_tuong_ve
    {
        public Hinh_lap_phuong():base()
        {            
            Loai = 0;
        }
        public override void Ve(GLUquadric quadric)
        {
             base.Ve(quadric);
             Ve_hinh_lap_phuong(1.0f );
             GL.glPopMatrix();
             
             if (Su_dung_trong_suot)
                 Ket_thuc_trong_suot();
             if (!Su_dung_texture)
                 GL.glDisable(GL.GL_TEXTURE_2D);
        }

    }
    public class Hinh_cau : Doi_tuong_ve
    {
        public Hinh_cau(): base()
        {            
            Loai = 1;
        }
        public override void Ve(GLUquadric quadric)
        {
            base.Ve(quadric);           

            Ve_hinh_cau(quadric, 1.0f);

            GL.glPopMatrix();
            if (Su_dung_trong_suot)
                Ket_thuc_trong_suot();
            if (!Su_dung_texture)
                GL.glDisable(GL.GL_TEXTURE_2D);
            
        }       
        
    }
    public class Hinh_ong : Doi_tuong_ve
    {
        public Hinh_ong():base()
        {
            
            Loai = 2;
        }
        public override void Ve(GLUquadric quadric)
        {
            base.Ve(quadric);
            GL.glTranslatef(Toa_do[0], Toa_do[1], Toa_do[2]-1.5f);
            Ve_hinh_tru(quadric, 1.0f,3.0f);
            GL.glPopMatrix();
            if (Su_dung_trong_suot)
                Ket_thuc_trong_suot();
            if (!Su_dung_texture)
                GL.glDisable(GL.GL_TEXTURE_2D);
        }

    }
    public class Hinh_non : Doi_tuong_ve
    {
        public Hinh_non():base()
        {            
            Loai = 3;
        }
        public override void Ve(GLUquadric quadric)
        {
            base.Ve(quadric);
            Ve_hinh_non(quadric, 1.0f,2.0f);
            GL.glPopMatrix();
            if (Su_dung_trong_suot)
                Ket_thuc_trong_suot();
            if (!Su_dung_texture)
                GL.glDisable(GL.GL_TEXTURE_2D);
        }
    }
    public class May_bay : Doi_tuong_ve
    {
        public May_bay()
            : base()
        {            
            Loai = 4;
        }
        public override void Ve(GLUquadric quadric)
        {
            base.Ve(quadric);
            
            Ve_may_bay(quadric);
            
            GL.glPopMatrix();          
            if (Su_dung_trong_suot)
                Ket_thuc_trong_suot();           
            if (!Su_dung_texture)
                GL.glDisable(GL.GL_TEXTURE_2D);
        }
        
    }

}
