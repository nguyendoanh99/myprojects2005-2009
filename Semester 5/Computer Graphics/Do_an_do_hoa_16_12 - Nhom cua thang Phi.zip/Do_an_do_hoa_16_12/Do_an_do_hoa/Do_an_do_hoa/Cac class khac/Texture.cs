﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using CsGL.OpenGL;
using System.Drawing.Imaging;
namespace Do_an_do_hoa
{
    public class CTexture
    {
        private Bitmap _anh;
        private uint[] texture = new uint[3];
        private bool bTexture = true;
        private uint[] _texture_envi = { GL.GL_MODULATE, GL.GL_REPLACE, GL.GL_DECAL, GL.GL_BLEND };
        private int _loai_texture;//0,1,2
        private int _loai_moi_truong;
        public bool Thay_doi_texture
        {
            get { return bTexture; }
            set { bTexture = value; }
        }
        public uint[] Texture
        {
            get { return texture; }
            set { texture = value; }
        }
        

        public int Loai_moi_truong
        {
            get { return _loai_moi_truong; }
            set { _loai_moi_truong = value; }
        }
        public int Loai_loc
        {
            get { return _loai_texture; }
            set { _loai_texture = value; }
        }
        public Bitmap Anh
        {
            get { return _anh; }
            set { _anh = value; }
        }
        public CTexture()
        {

            Loai_loc = 0;
        }
        public void Load()
        {
            GL.glEnable(GL.GL_TEXTURE_2D);
            // The Bitmap Image For Our Texture
            Rectangle rectangle;														// The Rectangle For Locking The Bitmap In Memory
            BitmapData bitmapData = new BitmapData();
            rectangle = new Rectangle(0, 0, Anh.Width, Anh.Height);			// Select The Whole Bitmap
            bitmapData = Anh.LockBits(rectangle, ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

            GL.glGenTextures(3, texture);												// Create 3 Textures
            switch (Loai_loc)
            {
                case 0:
                    // Create Nearest Filtered Texture
                    GL.glBindTexture(GL.GL_TEXTURE_2D, texture[0]);
                    GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_NEAREST);
                    GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_NEAREST);
                    GL.glTexImage2D(GL.GL_TEXTURE_2D, 0, (int)GL.GL_RGB8, Anh.Width, Anh.Height, 0, GL.GL_BGR_EXT, GL.GL_UNSIGNED_BYTE, bitmapData.Scan0);
                    break;
                case 1:
                    // Create Linear Filtered Texture
                    GL.glBindTexture(GL.GL_TEXTURE_2D, texture[1]);
                    GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR);
                    GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR);
                    GL.glTexImage2D(GL.GL_TEXTURE_2D, 0, (int)GL.GL_RGB8, Anh.Width, Anh.Height, 0, GL.GL_BGR_EXT, GL.GL_UNSIGNED_BYTE, bitmapData.Scan0);
                    break;
                case 2:
                    // Create MipMapped Texture
                    GL.glBindTexture(GL.GL_TEXTURE_2D, texture[2]);
                    GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR_MIPMAP_NEAREST);
                    GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR_MIPMAP_NEAREST);
                    GL.gluBuild2DMipmaps(GL.GL_TEXTURE_2D, (int)GL.GL_RGB8, Anh.Width, Anh.Height, GL.GL_BGR_EXT, GL.GL_UNSIGNED_BYTE, bitmapData.Scan0);
                    //Anh.Dispose();
                    break;
            }
            GL.glTexEnvi(GL.GL_TEXTURE_ENV, GL.GL_TEXTURE_ENV_MODE, (int)_texture_envi[Loai_moi_truong]);
            Anh.UnlockBits(bitmapData);
            //Anh.Dispose();
        }
    }
}
