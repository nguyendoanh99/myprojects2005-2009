﻿using System;
using System.Collections.Generic;
using System.Text;
using CsGL.OpenGL;
namespace Do_an_do_hoa
{
    public class CFog
    {
        private float[] _fog_color = { 0.5f, 0.5f, 0.5f, 1.0f };
        private float _fog_start;
        private float _fog_end;
        private uint[] _fog_mode = { GL.GL_LINEAR, GL.GL_EXP, GL.GL_EXP2 };
        private int _loai_suong;
        private float _fog_density;
        public float[] Fog_color
        {
            get { return _fog_color; }
            set { _fog_color = value; }
        }
        

        public float Fog_start
        {
            get { return _fog_start; }
            set { _fog_start = value; }
        }
       

        public float Fog_end
        {
            get { return _fog_end; }
            set { _fog_end = value; }
        }
        

        public int Loai_suong
        {
            get { return _loai_suong; }
            set { _loai_suong = value; }
        }
       

        public float Fog_density
        {
            get { return _fog_density; }
            set { _fog_density = value; }
        }
        public CFog()
        {
            Fog_density = 1.0f;
            Fog_start = 0.5f;
            Fog_end = 2f;
        }
        public void Phat_suong_mu()
        {

            GL.glEnable(GL.GL_FOG);
            GL.glFogi(GL.GL_FOG_MODE, (int)_fog_mode[Loai_suong]);
            GL.glFogfv(GL.GL_FOG_COLOR, Fog_color);
            GL.glFogf(GL.GL_FOG_START, Fog_start);
            GL.glFogf(GL.GL_FOG_END, Fog_end);
            GL.glFogf(GL.GL_FOG_DENSITY, Fog_density);
            GL.glHint(GL.GL_FOG_HINT, GL.GL_DONT_CARE);
            
        }
        public void Ket_thuc_suong_mu()
        {
            GL.glDisable(GL.GL_FOG);
        }
    }
}
