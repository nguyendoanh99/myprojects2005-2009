using System;
using System.Collections.Generic;
using System.Text;
using CsGL.OpenGL;
namespace Do_an_do_hoa
{
    public class CPhep_chieu
    {
        private int _loai_chieu;//0:Song_song,1:Phoi_canh,2:Frustum
        private float[] _song_song;
        private float[] _phoi_canh;
        private float[] _frustum;
        public float[] Song_song
        {
            get { return _song_song; }
            set { _song_song = value; }
        }
        
        

        public int Loai_chieu
        {
            get { return _loai_chieu; }
            set { _loai_chieu = value; }
        }
        
        public float[] Phoi_canh
        {
            get { return _phoi_canh; }
            set { _phoi_canh = value; }
        }       

        public float[] Frustum
        {
            get { return _frustum; }
            set { _frustum = value; }
        }
        public CPhep_chieu()
        {
            Loai_chieu = 1;
            Song_song = new float[6];
            Song_song[0] = -1;
            Song_song[1] = 1;
            Song_song[2] = -1;
            Song_song[3] = 1;
            Song_song[4] = 1;
            Song_song[5] = 5f;
            Phoi_canh = new float[4];
            Phoi_canh[0] = 120;
            Phoi_canh[1] = 1;
            Phoi_canh[2] = 0.1f;
            Phoi_canh[3] = 8;
            Frustum = new float[6];
            Frustum[0] = -1;
            Frustum[1] = 1;
            Frustum[2] = -1;
            Frustum[3] = 1;
            Frustum[4] = 1;
            Frustum[5] = 5f;
        }
        public void Hien_thi()
        {
            if (Loai_chieu == 1)
                GL.gluPerspective(Phoi_canh[0], Phoi_canh[1],
                Phoi_canh[2], Phoi_canh[3]);
            else if (Loai_chieu == 0)
                GL.glOrtho(Song_song[0], Song_song[1], Song_song[2],
                Song_song[3], Song_song[4], Song_song[5]);
            else if (Loai_chieu == 2)
                GL.glFrustum(Frustum[0], Frustum[1], Frustum[2],
                Frustum[3], Frustum[4], Frustum[5]);
            
        }

    }
}
