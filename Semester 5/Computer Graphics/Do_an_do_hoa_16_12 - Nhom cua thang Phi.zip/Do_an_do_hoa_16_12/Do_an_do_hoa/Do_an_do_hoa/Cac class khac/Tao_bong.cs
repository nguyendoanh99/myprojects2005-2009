﻿using System;
using System.Collections.Generic;
using System.Text;
using CsGL.OpenGL;
namespace Do_an_do_hoa
{
    public class CTao_bong
    {
        private float[,] floorshadow;
        static float[] vplane = new float[4];        
        static float[] Light_position;
        public CTao_bong(float[] light)
    {
        
        Light_position = light;
        floorshadow = new float[4, 4];
        float[] v0 = { -3,-3f,3};
        float[] v1 = { 3, -3f,3};
        float[] v2 = { -3, -3f,-3};
        findplane(vplane, v0, v1, v2);
        shadowmatrix((float[,])floorshadow, vplane, Light_position);       
       
    }  
    
        
        public void Hien_thi(int Loai_hinh,GLUquadric Quadric,float[] light,bool Su_dung)
    {
        if (Su_dung)
        {
            Light_position = light;
            GL.glEnable(GL.GL_LIGHTING);
            GL.glColor3f(1,1, 1);
            
            Ve_mat_phang();
           
            GL.glDisable(GL.GL_DEPTH_TEST);
            GL.glDisable(GL.GL_LIGHTING);
            GL.glDisable(GL.GL_TEXTURE_2D);
            //GL.glLoadIdentity();
            GL.glPushMatrix();
            GL.glMultMatrixf(Chuyen_ma_tran(floorshadow));
            //GL.glMultMatrixf(Doi_tuong_ve.Ma_tran_hien_tai);
            
            //GL.glTranslatef(0, 3, 0);
            float [] Toa_do = frm_Man_hinh_chinh.Doi_tuong.Hinh_ve.Toa_do;
             float [] Goc_quay = frm_Man_hinh_chinh.Doi_tuong.Hinh_ve.Goc_quay;
             float [] Ty_le = frm_Man_hinh_chinh.Doi_tuong.Hinh_ve.Ty_le;
            GL.glTranslatef(Toa_do[0], Toa_do[1], Toa_do[2]);


            GL.glRotatef(Goc_quay[0], 1, 0, 0);
            GL.glRotatef(Goc_quay[1], 0, 1, 0);
            GL.glRotatef(Goc_quay[2], 0, 0, 1);
            GL.glScalef(Ty_le[0], Ty_le[1], Ty_le[2]);


           
            GL.glColor3f(0, 0, 0);
            Ve_doi_tuong(Loai_hinh, Quadric);


            GL.glPopMatrix();
            shadowmatrix((float[,])floorshadow, vplane, Light_position);


            GL.glEnable(GL.GL_DEPTH_TEST);
            GL.glEnable(GL.GL_LIGHTING);
        }      
            

    }
        private void Ve_doi_tuong(int Loai_hinh, GLUquadric Quadric)
        {
            switch (Loai_hinh)
            {
                case 0:

                    Doi_tuong_ve.Ve_hinh_lap_phuong(1.0f);
                    break;
                case 1:
                    Doi_tuong_ve.Ve_hinh_cau(Quadric,1.0f);
                    break;
                case 2:
                    Doi_tuong_ve.Ve_hinh_tru(Quadric, 1.0f, 3.0f);
                    break;
                case 3:
                    Doi_tuong_ve.Ve_hinh_non(Quadric, 1.0f, 2.0f);   
                    break;
                case 4:
                    Doi_tuong_ve.Ve_may_bay(Quadric);
                    break;
            }
        }
        public static void Ve_mat_phang()
        {        
            if(frm_Man_hinh_chinh.Doi_tuong.Hinh_ve.Su_dung_texture)
                GL.glEnable(GL.GL_TEXTURE_2D);        
            GL.glPushMatrix();
            GL.glTranslatef(0, 17, 0);
            GL.glBegin(GL.GL_QUADS);
            GL.glTexCoord2d(1, 0);
            GL.glVertex3f(20.0f, -20.0f, -20.0f);
            GL.glTexCoord2d(0, 0);
            GL.glVertex3f(-20.0f, -20.0f, -20.0f);
            GL.glTexCoord2d(0, 1);
            GL.glVertex3f(-20.0f, -20.0f, 20.0f);
            GL.glTexCoord2d(1, 1);
            GL.glVertex3f(20.0f, -20.0f, 20.0f);
            GL.glEnd();
            GL.glPopMatrix();

        }
        public void shadowmatrix(float[,] shadowMat,  float[] groundplane,  float[] lightpos)
    {
      float dot;

      //find dot product between light position vector and ground plane normal 
        dot = groundplane[0] * lightpos[0] +
        groundplane[1] * lightpos[1] +
        groundplane[2] * lightpos[2] +
        groundplane[3] * lightpos[3];
       
      shadowMat[0,0] = dot - lightpos[0] * groundplane[0];
      shadowMat[1, 0] = 0.0f -lightpos[0] * groundplane[1];
      shadowMat[2,0] = 0.0f -lightpos[0] * groundplane[2];
      shadowMat[3, 0] = 0.0f -lightpos[0] * groundplane[3];

      shadowMat[0,1] = 0.0f - lightpos[1] * groundplane[0];
      shadowMat[1, 1] = dot - lightpos[1] * groundplane[1];
      shadowMat[2,1] = 0.0f - lightpos[1] * groundplane[2];
      shadowMat[3, 1] =0.0f - lightpos[1] * groundplane[3];

      shadowMat[0,2] = 0.0f - lightpos[2] * groundplane[0];
      shadowMat[1, 2] = 0.0f - lightpos[2] * groundplane[1];
      shadowMat[2,2] = dot - lightpos[2] * groundplane[2];
      shadowMat[3, 2] = 0.0f - lightpos[2] * groundplane[3];

      shadowMat[0,3] = 0.0f - lightpos[3] * groundplane[0];
      shadowMat[1, 3] = 0.0f - lightpos[3] * groundplane[1];
      shadowMat[2,3] = 0.0f - lightpos[3] * groundplane[2];
      shadowMat[3, 3] = dot - lightpos[3] * groundplane[3];

}
        public void findplane(float[] plane,  float[] v0, float[] v1, float[] v2)
        {
          float[] vec0 = new float[3];
          float[] vec1 = new float[3];

          // need 2 vectors to find cross product 
          vec0[0] = v1[0] - v0[0];
          vec0[1] = v1[1] - v0[1];
          vec0[2] = v1[2] - v0[2];

          vec1[0] = v2[0] - v0[0];
          vec1[1] = v2[1] - v0[1];
          vec1[2] = v2[2] - v0[2];

          //find cross product to get A, B, and C of plane equation 
          plane[0] = vec0[1] * vec1[2] - vec0[2] * vec1[1];
          plane[1] = -(vec0[0] * vec1[2] - vec0[2] * vec1[0]);
          plane[2] = vec0[0] * vec1[1] - vec0[1] * vec1[0];

          plane[3] = -(plane[0] * v0[0] + plane[1] * v0[1] + plane[2] * v0[2]);
        }
        public float[] Chuyen_ma_tran( float[,] shadow)
        {
            float[] x = new float[16];
            for (int i = 0; i < 4; i++)
            {
                x[i] = shadow[0, i];
                x[i + 4] = shadow[1, i];
                x[i + 8] = shadow[2, i];
                x[i + 12] = shadow[3, i];
            }
            return x;
        }

    }
}
