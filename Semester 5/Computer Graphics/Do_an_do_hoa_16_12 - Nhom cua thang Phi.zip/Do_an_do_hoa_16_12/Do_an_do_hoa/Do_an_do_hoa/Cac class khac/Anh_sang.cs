﻿using System;
using System.Collections.Generic;
using System.Text;
using CsGL.OpenGL;
namespace Do_an_do_hoa
{
    public class CAnh_sang
    {

        private float[] _light_ambient;
        private float[] _light_diffuse;
        private float[] _light_specular;
        private float[] _light_position;        
        private float[] _material_ambient;
        private float[] _material_diffuse;
        private float[] _material_specular;
        private float[] _material_emission;
        private float   _material_shininess;
        public float[] Light_ambient
        {
            get { return _light_ambient; }
            set { _light_ambient = value; }
        }        

        public float[] Light_diffuse
        {
            get { return _light_diffuse; }
            set { _light_diffuse = value; }
        }

        
        public float[] Light_specular
        {
            get { return _light_specular; }
            set { _light_specular = value; }
        }

        

        public float[] Light_position
        {
            get { return _light_position; }
            set { _light_position = value; }
        }

        

        public float Material_shininess
        {
            get { return _material_shininess; }
            set { _material_shininess = value; }
        }

        
        public float[] Material_ambient
        {
            get { return _material_ambient; }
            set { _material_ambient = value; }
        }

        

        public float[] Material_diffuse
        {
            get { return _material_diffuse; }
            set { _material_diffuse = value; }
        }

       

        public float[] Material_specular
        {
            get { return _material_specular; }
            set { _material_specular = value; }
        }

        

        public float[] Material_emission
        {
            get { return _material_emission; }
            set { _material_emission = value; }
        }



        public CAnh_sang()
        {
            Light_ambient = new float[4];
            Light_diffuse = new float[4];
            Light_specular = new float[4];
            Light_position = new float[4];
            Material_ambient = new float[4];
            Material_diffuse = new float[4];
            Material_emission = new float[4];
            Material_specular = new float[4];
            for (int i = 0; i < 4; i++)
            {
                Light_ambient[i] = 0;
                Light_diffuse[i] = Light_specular[i] = 1.0f;
                Material_ambient[i] = 0;
                Material_diffuse[i] = 0.5f;
                Material_emission[i] = 0;
                Material_specular[i] = 0.33f;
            }
            Material_ambient[0] = 1.0f;

            Light_position[0] = 0.0f;
            Light_position[1] = 2.5f;
            Light_position[2] = -1f;
            Light_position[3] = 1.0f;

            Material_shininess = 10.0f;//0<x<128.0f

        }


        public void Phat_anh_sang()
        {
            GL.glEnable(GL.GL_LIGHTING);

            GL.glEnable(GL.GL_LIGHT0);
            GL.glLightfv(GL.GL_LIGHT0, GL.GL_AMBIENT, Light_ambient);
            GL.glLightfv(GL.GL_LIGHT0, GL.GL_DIFFUSE, Light_diffuse);
            GL.glLightfv(GL.GL_LIGHT0, GL.GL_SPECULAR, Light_specular);


            GL.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION, Light_position);

            GL.glEnable(GL.GL_COLOR_MATERIAL);
            GL.glColorMaterial(GL.GL_FRONT, GL.GL_AMBIENT_AND_DIFFUSE);
            GL.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_AMBIENT, Material_ambient);
            GL.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_DIFFUSE, Material_diffuse);
            GL.glMaterialfv(GL.GL_FRONT, GL.GL_SPECULAR, Material_specular);
            GL.glMaterialfv(GL.GL_FRONT, GL.GL_EMISSION, Material_emission);
            GL.glMaterialf(GL.GL_FRONT, GL.GL_SHININESS, Material_shininess);


        }
        public void Ket_thuc_phat_sang()
        {
            //

            GL.glDisable(GL.GL_LIGHT0);
            //GL.glDisable(GL.GL_LIGHTING);
        }
        
    }
}
