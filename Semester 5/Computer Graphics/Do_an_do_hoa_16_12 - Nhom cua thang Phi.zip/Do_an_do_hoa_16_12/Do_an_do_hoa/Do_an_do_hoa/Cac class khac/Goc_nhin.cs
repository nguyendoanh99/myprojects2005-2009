using System;
using System.Collections.Generic;
using System.Text;
using CsGL.OpenGL;
namespace Do_an_do_hoa
{
    public class CGoc_nhin
    {

        private float[] _gia_tri;

        public float[] Gia_tri
        {
            get { return _gia_tri; }
            set { _gia_tri = value; }        }



        public CGoc_nhin()
        {
            Gia_tri = new float[9];
            Gia_tri[0] = 0.2f;
            Gia_tri[1] = 3f;
            Gia_tri[2] = 0.3f;
            Gia_tri[3] = Gia_tri[4] = Gia_tri[5] = Gia_tri[6] = Gia_tri[8] = 0;
            Gia_tri[7] = 1;
        }
        public void Hien_thi()
        {
            GL.gluLookAt(Gia_tri[0], Gia_tri[1], Gia_tri[2],
                         Gia_tri[3], Gia_tri[4], Gia_tri[5],
                         Gia_tri[6], Gia_tri[7], Gia_tri[8]);
        }

    }
}
