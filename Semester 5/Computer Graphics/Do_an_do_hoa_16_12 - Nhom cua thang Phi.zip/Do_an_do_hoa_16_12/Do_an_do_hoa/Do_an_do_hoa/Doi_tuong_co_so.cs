using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using CsGL.OpenGL;
using System.Drawing;
using System.Windows.Forms;

namespace Do_an_do_hoa
{
    public class Doi_tuong_OPENGL : OpenGLControl
    {
        #region "Thuoc_tinh"
        private int _loai;
        private float[] _mau_nen;
        private float[] _mau_nen_1;  //dung de quay lai mau ban dau khi tat suong mu
        private GLUquadric _quadric;
        private Doi_tuong_ve _hinh_ve;
        private static bool _ve_khung;

        private bool _ve_luoi_nen;

        

        private static bool _su_dung_suong_mu;
        private CFog _suong_mu;
        private CGoc_nhin _goc_nhin;

        
        private CPhep_chieu _phep_chieu;

        private bool _su_dung_anh_sang;

        private CAnh_sang _anh_sang;

        private bool _su_dung_tao_bong;

        private bool _su_dung_truc_toa_do;        

        private CTao_bong _tao_bong;

        

       

       
        #endregion
        #region "Property"
        public static  bool Ve_khung
        {
            get { return _ve_khung; }
            set { _ve_khung = value; }
        }
        public  bool Ve_luoi_nen
        {
            get { return _ve_luoi_nen; }
            set { _ve_luoi_nen = value; }
        }
        public int Loai
        {
            get { return _loai; }
            set { _loai = value; }
        }
        public float[] Mau_nen
        {
            get { return _mau_nen; }
            set { _mau_nen = value; }
        }
        public bool Su_dung_anh_sang
        {
            get { return _su_dung_anh_sang; }
            set { _su_dung_anh_sang = value; }
        }
        public CAnh_sang Anh_sang
        {
            get { return _anh_sang; }
            set { _anh_sang = value; }
        }
        public GLUquadric quadric
        {
            get { return _quadric; }
            set { _quadric = value; }
        }
        public Doi_tuong_ve Hinh_ve
        {
            get { return _hinh_ve; }
            set { _hinh_ve = value; }
        }
        public static bool Su_dung_suong_mu
        {
            get { return _su_dung_suong_mu; }
            set { _su_dung_suong_mu = value; }
        }
        public CFog Suong_mu
        {
            get { return _suong_mu; }
            set { _suong_mu = value; }
        }
        public CPhep_chieu Phep_chieu
        {
            get { return _phep_chieu; }
            set { _phep_chieu = value; }
        }
        public CGoc_nhin Goc_nhin
        {
            get { return _goc_nhin; }
            set { _goc_nhin = value; }
        }
        
        public CTao_bong Tao_bong
        {
            get { return _tao_bong; }
            set { _tao_bong = value; }
        }

        public bool Su_dung_tao_bong
        {
            get { return _su_dung_tao_bong; }
            set { _su_dung_tao_bong = value; }
        }
        public bool Su_dung_truc_toa_do
        {
            get { return _su_dung_truc_toa_do; }
            set { _su_dung_truc_toa_do = value; }
        }
        
        #endregion
        #region "Ham"
        public Doi_tuong_OPENGL()
        {
            Loai = 1;
          
            Mau_nen = new float[3];
            _mau_nen_1 = new float[3];
            quadric = GL.gluNewQuadric();												// Create A Quadric Object
            GL.gluQuadricNormals(quadric, GL.GLU_SMOOTH);									// Create Smooth Normals
            GL.gluQuadricTexture(quadric, (byte)GL.GL_TRUE);

            Hinh_ve = new Doi_tuong_ve();
            Suong_mu = new CFog();
            Su_dung_suong_mu = false;
            Phep_chieu = new CPhep_chieu();
            Goc_nhin = new CGoc_nhin();
            Anh_sang = new CAnh_sang();
            Su_dung_anh_sang = false;
            Tao_bong = new CTao_bong(Anh_sang.Light_position);
            Su_dung_tao_bong = true;
            
        }
        public void Hien_thi()
        {
            GL.glClearDepth(1.0f);

            GL.glEnable(GL.GL_DEPTH_TEST);
            GL.glDepthFunc(GL.GL_LEQUAL);
            GL.glHint(GL.GL_PERSPECTIVE_CORRECTION_HINT, GL.GL_NICEST);
            GL.glShadeModel(GL.GL_SMOOTH);
            GL.glClearColor(Mau_nen[0], Mau_nen[1], Mau_nen[2], 1.0f);						// Black Background
            GL.glClearColor(_mau_nen_1[0], _mau_nen_1[1], _mau_nen_1[2], 1.0f);

            if (Su_dung_suong_mu)
            {
                Suong_mu.Phat_suong_mu();
                _mau_nen_1 = Suong_mu.Fog_color;
            }
            
            else
                _mau_nen_1 = Mau_nen;
            if (Su_dung_anh_sang)
            {
                Anh_sang.Phat_anh_sang();

                Tao_bong.Hien_thi(Hinh_ve.Loai, quadric, Anh_sang.Light_position, Su_dung_tao_bong);
            }
            if(Ve_luoi_nen)
                Doi_tuong_ve.Ve_luoi_nen();
            if (Su_dung_truc_toa_do)
                Doi_tuong_ve.Ve_truc_toa_do_oxyx();
            if (Ve_khung)
                GL.gluQuadricDrawStyle(quadric, GL.GLU_LINE);
            else
                GL.gluQuadricDrawStyle(quadric, GL.GLU_FILL);
            

            Hinh_ve.Ve(quadric);
            if (Su_dung_anh_sang)
            {//ve mat troi
                GL.glDisable(GL.GL_LIGHTING);
                GL.glDisable(GL.GL_TEXTURE_2D);
                GL.glColor3f(1, 1, 0);
                GL.glPushMatrix();
                GL.glTranslatef(Anh_sang.Light_position[0], Anh_sang.Light_position[1], Anh_sang.Light_position[2]);
                GL.glutSolidSphere(0.1f, 20, 20);
                GL.glPopMatrix();
            }
            //ve mat troi
            if (Su_dung_anh_sang)
                Anh_sang.Ket_thuc_phat_sang();
            if (Su_dung_suong_mu)
                Suong_mu.Ket_thuc_suong_mu();
        }
        protected override void OnPaint( PaintEventArgs e)
        {
            base.OnPaint(e);
            Size s = Size;

            if (s.Height == 0)
                s.Height = 1;
            GL.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT | GL.GL_STENCIL_BUFFER_BIT);
            GL.glViewport(0, 0, s.Width, s.Height);

            GL.glMatrixMode(GL.GL_PROJECTION);// Ma tran hinh chieu trong khong gian 3 chieu

            GL.glLoadIdentity(); // Reset ma tran hinh chieu 
            
            //GL.gluPerspective(120f, (double)s.Width / (double)s.Height, 0.5f, 8f);
            Phep_chieu.Hien_thi();

            GL.glMatrixMode(GL.GL_MODELVIEW);          // Ma tran mo hinh  
            // Reset ma tran mo hinh 
            GL.glLoadIdentity();
            
            Goc_nhin.Hien_thi();
            
            Hien_thi();
            
            
        }
        private bool Chon_nhap_doi = true;
        private float taspect;
        protected override void OnDoubleClick(EventArgs e)
        {
            base.OnDoubleClick(e);
            if (Chon_nhap_doi)
            {
                this.Parent.Dock = DockStyle.Fill;
                taspect = this.Phep_chieu.Phoi_canh[1];
                this.Phep_chieu.Phoi_canh[1] = (float)this.Width / this.Height;
                Chon_nhap_doi = false;
            }
            else
            {
                this.Parent.Dock = DockStyle.Right;
                this.Phep_chieu.Phoi_canh[1] = taspect;
                Chon_nhap_doi = true;
            }
        }
        private bool flagMouse = false;
        private int xcu,ycu;
        protected  override void  OnMouseDown( MouseEventArgs e)
        {
            flagMouse = true;
            xcu = e.X; 
            ycu = e.Y;
        }        
        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (flagMouse)
            {
                Hinh_ve.Goc_quay[0] += (e.Y - ycu)/100.0f;
                Hinh_ve.Goc_quay[1] += (e.X - xcu)/100.0f;
                for (int i = 0; i < 2; i++)
                {
                    Hinh_ve.Goc_quay[i] = Math.Max(Hinh_ve.Goc_quay[i], -360);
                    Hinh_ve.Goc_quay[i] = Math.Min(Hinh_ve.Goc_quay[i], 360);
                    frm_Man_hinh_chinh.Goc_quay[i].Value = (float)Math.Round(Hinh_ve.Goc_quay[i], 0);
                    frm_Man_hinh_chinh.Goc_quay[i].Text = frm_Man_hinh_chinh.Goc_quay[i].Value.ToString();
                }
            }

        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            flagMouse = false;
        }

        
        #endregion        
    }
    
    public class Cell_button:TextBox
    {
        private float _min, _max, _value, _step;
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public float Step
        {
            get { return _step; }
            set { _step = value; }
        }

        public float Value
        {
            get { return _value; }
            set { _value = value; }
        }

        public float Max
        {
            get { return _max; }
            set { _max = value; }
        }

        public float Min
        {
            get { return _min; }
            set { _min = value; }
        }        
    }
}
