#include "syscall.h"

int ChuyenSo(char *s)
{
	int kq = 0;
	int i = 0;
	while (s[i] >= '0' && s[i] <= '9')
	{
		kq = kq * 10 + (s[i] - '0');
		++i;
	}
	return kq;
}

void ChuyenChuoi(int value, char *s)
{
	char temp[100];
	int i = 0;
	int len;

	if (value == 0)
	{
		s[0] = '0';
		s[1] = 0;
		return;
	}

	while (value != 0)
	{
		temp[i] = (value % 10) + '0';
		value = value /10;
		++i;
	}

	len = i;
	i--;
	for (; i >= 0; --i)
		s[len - i - 1] = temp[i];
	s[len] = 0;
}
void ReadDataFromFile(char *filename, int *value)
{
	char s[10];
	int id;
	int len;

	id = Open(filename, ReadOnly);
	len = Read(s, 10, id);
	s[len] = 0;
	*value = ChuyenSo(s);
	
	Close(id);
}
void WriteDataToFile(char *filename, int value)
{
	int id;
	char s[10];
	int i;
	ChuyenChuoi(value, s);
	id = Open(filename, ReadWrite);
	for (i = 0; i < 9; ++i)
		if (s[i] < '0' || s[i] > '9')
			s[i] = ' ';
	s[9] = 0;
	Write(s, 10, id);
	Close(id);

}
void Cross()
{
	int value;
	char s[10];
	Write("\t(East) Tui dang bang qua vuc ne, hi\n", 100, 1);
	ReadDataFromFile("./test/MonkeyNumCrossedE.txt", &value);
	value++;
	WriteDataToFile("./test/MonkeyNumCrossedE.txt", value);
}

void Decrease(char *filename, int Equeue)
{
	--Equeue;
	WriteDataToFile(filename, Equeue);
}

void main()
{
	int Equeue;
	
	while(1)
	{
		wait("Rope");
		while(1)
		{
			wait("Emutex");
			ReadDataFromFile("./test/Equeue.txt", &Equeue); // Doc Equeue len tu file.
			if(Equeue == 0)
			{
				signal("Emutex");
				signal("Rope");
				break;
			}
			Cross(); // bang qua vuc.
			Decrease("./test/Equeue.txt", Equeue); // Giam Equeue va luu lai xuong file.
			
			signal("Emutex");
			signal("Rope");
		}
//		Write("\tRope\n", 100, 1);
//		signal("Rope");
	}
}
