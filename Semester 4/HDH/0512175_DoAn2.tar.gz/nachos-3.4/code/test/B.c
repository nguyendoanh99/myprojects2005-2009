#include "syscall.h"
void main()
{
	SpaceId id;
	Write("Tieu trinh B\n", 100, 1);
	Write("Test\n", 80, 1);
	id = Exec("&./test/help");
	Join(id);
	Write("Ket thuc B\n", 90, 1);
	Exit(1);
}
