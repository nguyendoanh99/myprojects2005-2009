#include "syscall.h"

int
main()
{
	SpaceId id;
	int flag;
	char str[100];
	Write("Tien trinh cha\n", 100, 1);
	id = Exec("./test/B");
	flag = Join(id);
//	if (flag == -1)
//		Write("Khong the join dc", 100, 1);
	Write("Ket thuc tien trinh cha\n", 50, 1);
//	Read(str, 100, 0);
	Exit(0);





/*
    SpaceId newProc;
    OpenFileId input = ConsoleInput;
    OpenFileId output = ConsoleOutput;
    char prompt[2], ch, buffer[60];
    int i;

    prompt[0] = '-';
    prompt[1] = '-';

    while( 1 )
    {
	Write(prompt, 2, output);

	i = 0;
	
	do {
	
	    Read(&buffer[i], 1, input); 

	} while( buffer[i++] != '\n' );

	buffer[--i] = '\0';

	if( i > 0 ) {
		newProc = Exec(buffer);
		Join(newProc);
	}
    }
*/
}

