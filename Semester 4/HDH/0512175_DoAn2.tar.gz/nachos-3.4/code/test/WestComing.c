#include "syscall.h"

int ChuyenSo(char *s)
{
	int kq = 0;
	int i = 0;
	while (s[i] >= '0' && s[i] <= '9')
	{
		kq = kq * 10 + (s[i] - '0');
		++i;
	}
	return kq;
}

void ChuyenChuoi(int value, char *s)
{
	char temp[100];
	int i = 0;
	int len;

	if (value == 0)
	{
		s[0] = '0';
		s[1] = 0;
		return;
	}

	while (value != 0)
	{
		temp[i] = (value % 10) + '0';
		value = value /10;
		++i;
	}

	len = i;
	i--;
	for (; i >= 0; --i)
		s[len - i - 1] = temp[i];
	s[len] = 0;
}

void ReadDataFromFile(char *filename, int *value)
{
	char s[10];
	int id;
	int len;

	id = Open(filename, ReadOnly);
	len = Read(s, 10, id);
	s[len] = 0;
	*value = ChuyenSo(s);
	
	Close(id);
}

void WriteDataToFile(char *filename, int value)
{
	int id;
	char s[10];
	int i;
	ChuyenChuoi(value, s);
	id = Open(filename, ReadWrite);
	for (i = 0; i < 9; ++i)
		if (s[i] < '0' || s[i] > '9')
			s[i] = ' ';
	s[9] = 0;
	Write(s, 10, id);
	Close(id);

}

void Increase(char *filename, int Equeue)
{
	++Equeue;
	WriteDataToFile(filename, Equeue);

}

void main()
{
	int MonkeyNumW; // So luong khi.
	int MonkeyNumE; // So luong khi.

	int Wqueue; // So khi trong hang doi.
	int i;
	int MonkeyNumCrossedW;
	int MonkeyNumCrossedE;
	char s[10];
	wait("Wmutex");
	ReadDataFromFile("./test/MonkeyNumW.txt", &MonkeyNumW);
	ReadDataFromFile("./test/MonkeyNumE.txt", &MonkeyNumE);
	signal("Wmutex");

	
	while(1)
	{
		wait("Wmutex");
		ReadDataFromFile("./test/Wqueue.txt", &Wqueue);
		ReadDataFromFile("./test/MonkeyNumCrossedW.txt", &MonkeyNumCrossedW);
		if(MonkeyNumCrossedW == MonkeyNumW)
		{
			Write("\n-------------------------TAT CA DA DI DEN BO BUC PHIA TAY--------------------\n", 100, 1);
			Read(s, 10, 0);
			ReadDataFromFile("./test/MonkeyNumCrossedE.txt", &MonkeyNumCrossedE);		
			signal("Wmutex");
	
			if (MonkeyNumCrossedE == MonkeyNumE)
				signal("mutexmain");			

			return;
		}
		if (Wqueue + MonkeyNumCrossedW < MonkeyNumW)
			Increase("./test/Wqueue.txt", Wqueue);// tang Wqueue va luu lai xuong file.
		signal("Wmutex");		

	}
}
