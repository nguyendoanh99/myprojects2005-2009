#include "syscall.h"
void ChuyenChuoi(int value, char *s)
{
	char temp[100];
	int i = 0;
	int len;

	if (value == 0)
	{
		s[0] = '0';
		s[1] = 0;
		return;
	}

	while (value != 0)
	{
		temp[i] = (value % 10) + '0';
		value = value /10;
		++i;
	}

	len = i;
	i--;
	for (; i >= 0; --i)
		s[len - i - 1] = temp[i];
	s[len] = 0;
}
void WriteDataToFile(char *filename, int value)
{
	int id;
	char s[10];
	int i;
	ChuyenChuoi(value, s);
	id = Open(filename, ReadWrite);
	for (i = 0; i < 9; ++i)
		if (s[i] < '0' || s[i] > '9')
			s[i] = ' ';
	s[9] = 0;
	Write(s, 10, id);
	Close(id);

}

void main()
{
	WriteDataToFile("./test/MonkeyNumCrossedE.txt", 0);
	WriteDataToFile("./test/Equeue.txt", 0);
	WriteDataToFile("./test/MonkeyNumCrossedW.txt", 0);
	WriteDataToFile("./test/Wqueue.txt", 0);

	CreateSemaphore("Rope", 1);
	CreateSemaphore("Wmutex", 1);
	CreateSemaphore("Emutex", 1);
	CreateSemaphore("mutexmain", 0);
	Exec("&./test/EastComing");
	Exec("&./test/EastCross");
	Exec("&./test/WestComing");
	Exec("&./test/WestCross");

	wait("mutexmain");
}