#ifndef _CFDCOUT_H
#define _CFDCOUT_H

#include "syscall.h"
#include "CFDBase.h"
/*
	CFDCout dung de thuc hien cac thao tac xuat ra man hinh,
	nen cac phuong thuc: fCreate, fOpen, fRead, fClose, fSeek 
	khong co tac dung. Tat ca cac ham tren khi duoc goi se
	tra ve gia tri -1 (co loi)
*/
class CFDCout: public CFDBase
{
public:
	CFDCout();
	virtual ~CFDCout();

	int fCreate(char *name);		// Tao file
	int fOpen(char *name);			// Mo file
	int fWrite(char *buffer, int charcount);// Ghi du lieu len file
	int fRead(char *buffer, int charcount); // Doc du lieu tu file
	int fClose();				// Dong file
	int fSeek(int pos);			// Di chuyen con tro file
};

#endif
