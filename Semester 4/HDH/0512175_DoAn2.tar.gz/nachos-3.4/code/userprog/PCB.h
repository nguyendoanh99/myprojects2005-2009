#ifndef PCB_H
#define PCB_H
#include "thread.h"
#include "synch.h"

class PCB
{
private:
	Semaphore *joinsem; // semaphore cho qua trinh join
	Semaphore *exitsem; // semaphore cho qua trinh exit
	Semaphore *mutex;

	int exitcode;
	Thread *thread;
	int pid;
	int numwait; // so tien trinh da join.
	bool BackGround;

public:

	int parentID; // ID cua tien trinh cha.
	PCB(int id);
	~PCB();

	int Exec(char *filename, int pid); // nap chuong trinh co ten luu trong bien filename va processID se la pid.
	int GetID();
	int GetNumWait();
	void JoinWait();
	void ExitWait();
	void JoinRelease();
	void ExitRelease();
	void IncNumWait();
	void DecNumWait();
	void SetExitCode(int ec);
	int GetExitCode();
	char* getName();
	bool IsBackGround();
};

#endif
