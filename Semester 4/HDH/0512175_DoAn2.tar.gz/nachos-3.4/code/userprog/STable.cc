#include "STable.h"

STable::STable()
{
	bm = new BitMap(MAX_SEMAPHORE);
	for(int i = 0; i < MAX_SEMAPHORE; i++)
	{
		semTab[i] = NULL;
	}
}

STable::~STable()
{
	if(bm)
		delete bm;

	for(int i = 0; i < MAX_SEMAPHORE; i++)
	{
		if(semTab[i])
			delete semTab[i];
	}
}

// Ham create.
// Cong dung: tao semaphore moi.
// Input: name: ten semaphore, init: gia tri ban dau.
// Output: 0: thanh cong, -1: semaphore da ton tai roi, -2: het slot trong.
int STable::create(char *name, int init)
{
	for(int i = 0; i < MAX_SEMAPHORE; i++)
	{
		if(bm->Test(i) == true && strcmp(semTab[i]->GetName(), name)==0)
			return -1; // ten cua semaphore nay da ton tai roi.
	}

	for(int j = 0; j < MAX_SEMAPHORE; j++)
	{
		if(bm->Test(j) == false)
		{
			semTab[j] = new Sem(name, init);
			bm->Mark(j);
			return 0; // tao thanh cong
		}
	}

	return -2; // Khong con slot trong.
}

// Ham wait.
// Cong dung: wait semaphore co ten la "name".
// Input: name: ten semaphore muon wait.
// Output: 0: thanh cong, -1: ten khong hop le. 
int STable::wait(char *name)
{
	for(int i = 0; i < MAX_SEMAPHORE; i++)
	{
		if(bm->Test(i) == true && strcmp(semTab[i]->GetName(), name) == 0)
		{
			semTab[i]->wait();
			return 0; 
		}
	}

	return -1;
}

// Ham signal.
// Cong dung: signal semaphore co ten la "name".
// Input: name: ten semaphore muon signal.
// Output: 0: thanh cong, -1: ten khong hop la.
int STable::signal(char *name)
{	
	for(int i = 0; i < MAX_SEMAPHORE; i++)
	{
		if(bm->Test(i) == true && strcmp(semTab[i]->GetName(), name) == 0)
		{
			semTab[i]->signal();
			return 0;
		}
	}

	return -1;
}

