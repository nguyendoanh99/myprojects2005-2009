#include "PCB.h"
#include "system.h"

//----------------------------------------------------------------------
// StartProcess
// 	Run a user program.  Open the executable, load it into
//	memory, and jump to it.
//----------------------------------------------------------------------

void StartProcess(int thread)
{
	Thread *temp = (Thread*) thread;
	
	char *filename = temp->getName();
    OpenFile *executable = fileSystem->Open(filename);

    if (executable == NULL) {
	printf("Unable to open file %s\n", filename);
	return;
    }
    temp->space = new AddrSpace(filename);    
    currentThread->space = temp->space;

    delete executable;			// close file

    temp->space->InitRegisters();		// set the initial register values
    temp->space->RestoreState();		// load page table register

    machine->Run();			// jump to the user progam
    ASSERT(FALSE);			// machine->Run never returns;
					// the address space exits
					// by doing the syscall "exit"
}

PCB::PCB(int id)
{
	joinsem = new Semaphore("joinsem", 0);
	exitsem = new Semaphore("exitsem", 0);
	mutex = new Semaphore("mutex", 1);
	
	thread = new Thread("threadname");
	BackGround = false;
	exitcode = 0;
	pid = id;
	numwait = 0;
}

PCB::~PCB()
{
	if(joinsem)
		delete joinsem;
	if(exitsem)
		delete exitsem;
	if(mutex)
		delete mutex;

}
int PCB::Exec(char *filename,int id)
{
	mutex->P();
	
	if (filename[0] == '&')
	{
		BackGround = true;
		thread = new Thread(&filename[1]);
	}
	else
		thread = new Thread(filename);
	thread->processID = id;
	// id cua tien trinh cha
	thread->parentProcessID = currentThread->processID;
	DEBUG('q', "PCB::Exec()");
	thread->Fork(StartProcess,  (int) thread);

	mutex->V();
	
	return 1;
}
int PCB::GetID()
{
	return pid;
}

int PCB::GetNumWait()
{
	return numwait;
}

void PCB::JoinWait()
{
	joinsem->P();
}

void PCB::ExitWait()
{
	exitsem->P();
}

void PCB::JoinRelease()
{
	joinsem->V();
}

void PCB::ExitRelease()
{
	exitsem->V();
}

void PCB::IncNumWait()
{
	mutex->P();
	numwait++;
	mutex->V();
}

void PCB::DecNumWait()
{
	mutex->P();
	numwait--;
	mutex->V();
}

void PCB::SetExitCode(int ec)
{
	mutex->P();
	exitcode = ec;
	mutex->V();
}

int PCB::GetExitCode()
{
	return exitcode;
}

char* PCB::getName()
{
	return thread->getName();
}

bool PCB::IsBackGround()
{
	return BackGround;
}