#include "system.h"
#include "PTable.h"
#include "bitmap.h"

PTable::PTable(int size)
{
	bmsem = new Semaphore("bmsem", 1);
	bm = new BitMap(size);
	for(int i = 0; i < size; ++i)
	{
		pcb[i] = NULL;
		bm->Clear(i);
	}
	bm->Mark(0);
	psize = size;
}

PTable::~PTable()
{
	delete bm;
	for(int i = 0; i < psize; ++i)
		if(pcb[i] != NULL)
			delete pcb[i];
	delete bmsem;
}

int PTable::ExecUpdate(char *filename)
{
	bmsem->P();
	
	OpenFile *executable;
	// Khong ton tai file	
	if (filename[0] == '&')
		executable = fileSystem->Open(&filename[1]);
	else
		executable = fileSystem->Open(filename);

	if (executable == NULL) {	
		bmsem->V();
		return -1;
	}
	// Khong cho chay chinh no
	int kq;
	if (filename[0] == '&')
		kq = strcmp(&filename[1], currentThread->getName());
	else
		kq = strcmp(filename, currentThread->getName());

	if (kq == 0)
	{
		bmsem->V();
		return -1;
	}	

	int id = GetFreeSlot();
	// Khong con cho trong
	if (id == -1)
	{
		bmsem->V();
		return -1;
	}	

	pcb[id] = new PCB(id);
	pcb[id]->parentID = currentThread->processID;
	DEBUG('q', "ExecUpdate");
	pcb[id]->Exec(filename, id);
	bm->Mark(id);	

	// Tien trinh chay o che do background
	if (pcb[id]->IsBackGround() == true)
	{
		bmsem->V();
		currentThread->Yield ();
	}
	else
		bmsem->V();

    delete executable;			// close file	
	return id;
} 
int PTable::ExitUpdate(int ec)
{
	bmsem->P();

	DEBUG('d', "ExitUpdate() ");
	DEBUG('d', currentThread->getName());
	DEBUG('d', "\n ");
	int pid = currentThread->processID;
	
	if(pid == 0)
	{
		bmsem->V();
		interrupt->Halt();
	}

	pcb[pid]->SetExitCode(ec);

	DEBUG('d', "pcb[id]->JoinRelease()");
	DEBUG('d', currentThread->getName());
	DEBUG('d', "\n ");
	char *name = currentThread->getName();

	// Tien trinh khong phai dang chay o che do background
	if (pcb[pid]->IsBackGround() == false)
	{		
		pcb[pid]->JoinRelease();
		DEBUG('d', "pcb[id]->ExitWait()");
		DEBUG('d', currentThread->getName());
		DEBUG('d', "\n ");
		pcb[pid]->ExitWait();
	}

	currentThread->FreeMemory();
	Remove(pid);
	DEBUG('d', "currentThread->Finish() ");
	DEBUG('d', currentThread->getName());
	DEBUG('d', "\n ");
	bmsem->V();
	currentThread->Finish();

	return 1;
}
int PTable::JoinUpdate(int id)
{
	if (id < 0 || id >= psize)	
		return -1;

	if (IsExist(id) == false)
		return -1;

	if (pcb[id]->IsBackGround() == false)
	{
		DEBUG('d', "pcb[id]->JoinWait()");
		DEBUG('d', currentThread->getName());
		DEBUG('d', "\n ");
		pcb[id]->JoinWait();
		DEBUG('d', "pcb[id]->ExitRelease()");
		DEBUG('d', currentThread->getName());
		DEBUG('d', "\n ");

		// Xu ly loi neu co
//		bmsem->P();
//		pcb[id]->GetExitCode();
//		bmsem->V();

		pcb[id]->ExitRelease();

		DEBUG('d', "return JoinUpdate()");
		DEBUG('d', currentThread->getName());
		DEBUG('d', "\n ");
		return 0;
	}
	else
		return -1;
}
int PTable::GetFreeSlot()
{
	for(int i = 1; i < psize; ++i)
		if(bm->Test(i) == false)
			return i;

	return -1;
}

void PTable::Remove(int pid)
{
	bm->Clear(pid);
	delete pcb[pid];
	pcb[pid] = NULL;
}

bool PTable::IsExist(int pid)
{
	if(bm->Test(pid) == true)
		return true;
	return false;

}
