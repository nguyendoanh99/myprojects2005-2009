#ifndef _CFDCIN_H_
#define _CFDCIN_H_

#include "syscall.h"
#include "console.h"
#include "CFDBase.h"

class CFDCin: public CFDBase
{	
public:
	CFDCin();
	virtual ~CFDCin();

	int fCreate(char *name);
	OpenFileId fOpen(char *name);
	int fClose();
	int fRead(char *buffer, int charcount);	
	int fWrite(char *buffer, int charcount);
	int fSeek(int pos);
};

#endif
