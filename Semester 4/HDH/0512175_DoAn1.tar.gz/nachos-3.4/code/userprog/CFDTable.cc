#include "system.h"
#include "CFDTable.h"
#include "CFDCout.h"
#include "CFDRW.h"
#include "CFDCin.h"
#include "string.h"
#include "CFDRo.h"
/*
	Tim xem file co trong bang hay chua
	Neu co thi tra ve ID cua file trong bang
	Neu khong tim thay tra ve -1
*/
int CFDTable::FindID(char *name)
{
	// Bo qua 2 dong dau tien
	for (int i = 2; i < NUM; ++i)
		if (m_Tab[i].strPath != NULL && strcmp(m_Tab[i].strPath, name) == 0)
			return i;

	return -1;
}
/*
	 Tim xem bang con cho trong hay khong
	 Neu con cho trong thi tra ve ID cua dong trong
	 Neu khong con thi tra ve -1
*/
int CFDTable::FindFreeSlot()
{
	// Bo qua 2 o dau tien
	for (int i = 2; i < NUM; ++i)
		if (m_Tab[i].iCount == 0)
			return i;

	return -1;
}

CFDTable::CFDTable()
{
	// Khoi tao cac dong trong voi cac gia tri mac dinh
	for (int i = 2; i < NUM; ++i)
	{
		m_Tab[i].strPath = NULL;
		m_Tab[i].iCount = 0;
		m_Tab[i].fp = NULL;
	}
	// Khoi tao Console IO vao 2 dong dau cua bang
	m_Tab[ConsoleInput].strPath = NULL;
	m_Tab[ConsoleInput].iCount = 1;
	m_Tab[ConsoleInput].fp = new CFDCin;

	m_Tab[ConsoleOutput].strPath = NULL;
	m_Tab[ConsoleOutput].iCount = 1;
	m_Tab[ConsoleOutput].fp = new CFDCout;
	
	DEBUG('q', "pointer:%p\n", glSynchConsole);
}

CFDTable::~CFDTable()
{
	// Thu hoi nhung vung nho da cap phat	
	for (int i = 0; i < NUM; ++i)
	{
		if (m_Tab[i].strPath != NULL)
		{
			delete []m_Tab[i].strPath;
			m_Tab[i].strPath = NULL;
		}

		m_Tab[i].iCount = 0;
		
		if (m_Tab[i].fp != NULL)
		{
			delete m_Tab[i].fp;
			m_Tab[i].fp = NULL;
		}
	}
}
/*
			TAO FILE
Tham so:
	name:	ten file
Ket qua tra ve:
	0: 	thanh cong
	-1: 	that bai
Luu y:
	Chi tao 1 file rong, khong mo file
*/
int CFDTable::fdCreate(char *name)
{
	DEBUG('c', "fdCreate(%s)\n", name);
	CFDBase *fp = new CFDRo;
	int kq = fp->fCreate(name);
	
	delete fp;
	return kq;
}

/*	
			MO FILE
Tham so:
	name: 		ten file
	filetype:	kieu mo file (ReadOnly, ReadWrite)
Ket qua tra ve:
	ID cua file:	thanh cong
	-2:		truyen sai tham so
	-1:		that bai	
Luu y:
	Doi voi nhieu chuong trinh cung mo mot file thi
	filetype phu thuoc vao chuong trinh mo dau tien
*/
OpenFileId CFDTable::fdOpen(char *name, int filetype)
{
	DEBUG('t', "fdOpen(%s, %d)\n", name, filetype);
	int ID = FindID(name);
	
	// Neu file da mo thi tang bien iCount len 1
	if (ID != -1)
		++m_Tab[ID].iCount;
	else
	{	
		ID = FindFreeSlot();

		// Neu con dong trong trong bang thi them thong tin
		// file can mo vao dong trong
		if  (ID != -1)
		{
			switch (filetype)
			{
			case ReadOnly:		
				m_Tab[ID].fp = new CFDRo;
				break;
			case ReadWrite:	
				m_Tab[ID].fp = new CFDRW;
				break;
			default: // Khong co loai file tuong ung
				return -2;
			}
			
			// Neu mo file thanh cong thi them thong tin vao
			// dong trong
			if (m_Tab[ID].fp->fOpen(name) == 0)
			{
				DEBUG('g', "fdOpen: %d", ID);
				m_Tab[ID].strPath = new char[strlen(name) + 1];
				strcpy(m_Tab[ID].strPath, name);
				m_Tab[ID].iCount = 1;
			}
			else // Mo file that bai
			{
				delete m_Tab[ID].fp;
				m_Tab[ID].fp = NULL;
				return -1;
			}
		}
	}

	return ID;
}

/*
		GHI DU LIEU LEN FILE
Tham so:
	buffer:		chuoi can ghi
	charcount:	so ky tu dau tien cua buffer can ghi
	id:		ID cua file
Ket qua tra ve:
	So ky tu da ghi :	thanh cong
	-1:			that bai
*/
int CFDTable::fdWrite(char *buffer, int charcount, OpenFileId id)
{
	// Neu id khong nam trong bang
	if (id < 0 || id >= NUM)
		return -1;
	
	if (charcount <= 0)
		return -1;
	// Khong co chuoi
	if (buffer == NULL)
		return -1;
	// Khong co file tai dong id 
	if (m_Tab[id].fp == NULL)
		return -1;
	DEBUG('p', "fdWrite: %s\n", buffer);
	return m_Tab[id].fp->fWrite(buffer, charcount);
}

/*
		DOC DU LIEU TU FILE
Tham so:
	buffer:		chuoi nhan duoc sau khi doc file
	charcount:	so ky tu can doc
	id:		ID cua file
Ket qua tra ve:
	So ky tu da doc duoc:	thanh cong
	-2:			cham den cuoi file
	-1:			that bai
*/
int CFDTable::fdRead(char *buffer, int charcount, OpenFileId id)
{
	// Neu id khong nam trong bang
	if (id < 0 || id >= NUM)
		return -1;
	
	if (charcount <= 0)
		return -1;

	// Khong co file tai dong id 
	if (m_Tab[id].fp == NULL)
		return -1;

	return m_Tab[id].fp->fRead(buffer, charcount);
}

/*
		DONG FILE
Tham so:	
	id:	ID cua file can dong
Ket qua tra ve:
	0:	thanh cong
	-1:	that bai
Luu y:
	File chi duoc dong that su khi tat ca cac chuong
	trinh da mo file nay thuc hien thao tac dong file
*/
int CFDTable::fdClose(OpenFileId id)
{
	// id khong nam trong bang, hoac id = Console IO
	if (id < 2 || id >= NUM)
		return -1;

	// Neu file da dong thi bao loi
	if (m_Tab[id].iCount == 0)
		return -1;

	// Giam so chuong trinh mo file nay
	--m_Tab[id].iCount;
	
	// Neu tat ca cac chuong trinh da dong file
	// thi tien hanh dong file nay that su	
	if (m_Tab[id].iCount == 0)
	{
		delete []m_Tab[id].strPath;
		m_Tab[id].strPath = NULL;

		int kq =  m_Tab[id].fp->fClose();
		DEBUG('k', "fdClose kq:%d\n", kq);
		delete m_Tab[id].fp;
		m_Tab[id].fp = NULL;
	}
	
	return 0;
}

/*
		DI CHUYEN CON TRO CUA FILE
Tham so:
	pos:	vi tri muon di chuyen toi (pos = -1: di chuyen den cuoi file)
	id:	ID cua file can thuc hien thao tac di chuyen
Ket qua tra ve:
	vi tri that su cua con tro:	thanh cong
	-1:				that bai
*/
int CFDTable::fdSeek(int pos, OpenFileId id)
{
	// Neu id khong nam trong bang, id = Console ID
	if (id < 2 || id >= NUM)
		return -1;

	if (pos < -1)
		return -1;
	
	// Khong co file tai dong id 
	if (m_Tab[id].fp == NULL)
		return -1;

	return m_Tab[id].fp->fSeek(pos);
}
