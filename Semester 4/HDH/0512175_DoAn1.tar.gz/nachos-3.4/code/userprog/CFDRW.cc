#include "system.h"
#include "CFDRW.h"

CFDRW::CFDRW()
{
	m_File = NULL;
}

CFDRW::CFDRW(char *name)
{
	fOpen(name);
}

CFDRW::~CFDRW()
{
	fClose();
}

/*
			TAO FILE
Tham so:
	name:	ten file
Ket qua tra ve:
	0: 	thanh cong
	-1: 	that bai
Luu y:
	Neu tao mot file da co roi thi xem nhu bi loi
*/
int CFDRW::fCreate(char *name)
{
	DEBUG('c', "fCreate(%s)\n", name);

	if (fOpen(name) == -1)
		return fileSystem->Create(name, 0) ? 0 : -1;
	else
		return -1;

}

/*	
			MO FILE
Tham so:
	name: 		ten file
Ket qua tra ve:
	0:		thanh cong
	-1:		that bai
*/
int CFDRW::fOpen(char *name)
{
	DEBUG('g', "fOpen(%s)\n", name);
	m_File = fileSystem->Open(name);
	
	return (m_File != NULL) ? 0 : -1;
}

/*
		GHI DU LIEU LEN FILE
Tham so:
	buffer:		chuoi can ghi
	charcount:	so ky tu dau tien cua buffer can ghi
Ket qua tra ve:
	So ky tu da ghi :	thanh cong
	-1:			that bai
*/
int CFDRW::fWrite(char *buffer, int charcount)
{
	if (m_File == NULL || charcount <= 0)
		return -1;

	return m_File->Write(buffer, charcount);
}

/*
		DOC DU LIEU TU FILE
Tham so:
	buffer:		chuoi nhan duoc sau khi doc file
	charcount:	so ky tu can doc
Ket qua tra ve:
	So ky tu da doc duoc:	thanh cong
	-2:			cham den cuoi file
	-1:			that bai
*/
int CFDRW::fRead(char *buffer, int charcount)
{
	if (m_File == NULL || charcount <= 0)
		return -1;

	int kq = m_File->Read(buffer, charcount);
	if (kq == 0)
		kq = -2; // Doc cuoi file

	return kq;
}

/*
		DONG FILE
Ket qua tra ve:
	0:	thanh cong
	-1:	that bai
*/
int CFDRW::fClose()
{
	if (m_File != NULL)
	{
		delete m_File;
		m_File = NULL;
		return 0;
	}
	else
		return -1;
}

/*
		DI CHUYEN CON TRO CUA FILE
Tham so:
	pos:	vi tri muon di chuyen toi (pos = -1: di chuyen den cuoi file)
Ket qua tra ve:
	vi tri that su cua con tro:	thanh cong
	-1:				that bai
*/
int CFDRW::fSeek(int pos)
{
	if (pos < -1 || pos >= m_File->Length())
		return -1;
	
	return  m_File->Seek(pos);
}
