#include "system.h"
#include "CFDCout.h"

CFDCout::CFDCout()
{
	DEBUG('k', "\nCFCOUT: Constructor\n");
	// Neu doi tuong SynchConsole chua co thi cap phat
//	if (glSynchConsole == NULL)	
//		glSynchConsole = new SynchConsole;
	DEBUG('q', "pointer:%p\n", glSynchConsole);
}

CFDCout::~CFDCout()
{
	// Neu doi tuong SynchConsole ton tai thi huy
//	if (glSynchConsole != NULL)
//	{
//		DEBUG('k', "fClose(): Thu hoi Console");
//		delete glSynchConsole;
//	}

//	glSynchConsole = NULL;
}

// Phuong thuc fCreate khong duoc su dung
int CFDCout::fCreate(char *name)
{
	return -1;
}

// Phuong thuc fOpen khong duoc su dung
OpenFileId CFDCout::fOpen(char *name)
{
	return -1;
}

/*
		XUAT CHUOI RA MAN HINH
Tham so:
	buffer:		chuoi can xuat
	charcount:	so ky tu dau tien cua buffer can xuat
Ket qua tra ve:
	So ky tu da ghi :	thanh cong
	-1:			that bai
*/
int CFDCout::fWrite(char *buffer, int charcount)
{
	DEBUG('q', "pointer:%p\n", glSynchConsole);
	if (buffer != NULL && charcount > 0)
		return glSynchConsole->Write(buffer, charcount);
	
	return -1;
}

// Phuong thuc fRead khong duoc su dung
int CFDCout::fRead(char *buffre, int charcount)
{
	return -1;
}

// Phuong thuc fClose khong duoc su dung
int CFDCout::fClose()
{
	return -1;
}

// Phuong thuc fSeek khong duoc su dung
int CFDCout::fSeek(int pos)
{
	return -1;
}
