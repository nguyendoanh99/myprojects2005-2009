#ifndef _CFDTABLE_H
#define _CFDTABLE_H

#include "CFDBase.h"
#include "syscall.h"

// So dong toi da cua bang
#define NUM sizeof(m_Tab) / sizeof(Record)

class CFDTable
{
private:
	struct Record
	{
		char* strPath;	// Duong dan va ten file
		int iCount;	// So chuong trinh cung mo file nay
		CFDBase *fp;	// Dung de thao tac tren file
	} 
	m_Tab[10];		// m_Tab la 1 bang gom co 10 dong va 3 cot
				// trong do 2 dong dau de luu Console IO,
				// cac dong con lai luu thong tin ve cac 
				// file dang mo

	int FindFreeSlot();	// Tim mot dong trong trong bang
				// Tra ve ID tuong ung voi dong trong,
				// Tra ve -1 neu khong con dong trong
	int FindID(char *name); // Tim ID ung voi file co ten name
				// Khong tim thay tra ve -1
public:
	CFDTable();
	virtual ~CFDTable();
	
	int fdCreate(char *name); // Tao file
	OpenFileId fdOpen(char *name, int filetype); // Mo file		
	int fdWrite(char *buffer, int charcount, OpenFileId id); // Ghi du lieu len file
	int fdRead(char *buffer, int charcount, OpenFileId id); // Doc du lieu tu file
	int fdClose(OpenFileId id); // Dong file
	int fdSeek(int pos, OpenFileId id); // Di chuyen con tro cua file
};

#endif
