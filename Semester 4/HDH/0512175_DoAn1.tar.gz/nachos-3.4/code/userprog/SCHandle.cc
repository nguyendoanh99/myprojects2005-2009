#include "SCHandle.h"
#include "stdlib.h"
#include "memory.h"
#include "system.h"
#include "string.h"
/*
	Input:	- User space address (int)
		- Limit of buffer (int)
	Output:	- Buffer (char *)
	Purpose:  Copy buffer from User memory space to System memory space
*/
char *User2System(int virtAddr, int limit)
{
	int i; // index
	int oneChar;
	char *kernelBuf = NULL;
	
	kernelBuf = new char[limit + 1]; // need for terminal string
	if (kernelBuf == NULL)
		return kernelBuf;

	memset(kernelBuf, 0, limit + 1);
	
	// printf("\n Filename u2s:");
	for (i = 0; i < limit; ++i)
	{
		machine->ReadMem(virtAddr + i, 1, &oneChar);
		kernelBuf[i] = (char) oneChar;
		// printf("%c", kernelBuf[i]);
		if (oneChar == 0)
			break;
	}

	return kernelBuf;
}

/*
	Input:	- User space adress (int)
		- Limit of buffer (int)
		- Buffer (char[])
	Output: - Number of bytes copied (int)
	Purpose:  Copy buffer from System memory space to User memory space
*/
int System2User(int virtAddr, int len, char *buffer)
{
	if (len < 0) 
		return -1;
	
	if (len == 0)
		return len;

	int i = 0;
	int oneChar = 0;

	do 
	{
		oneChar = (int) buffer[i];
		machine->WriteMem(virtAddr + i, 1, oneChar);
		++i;
	}
	while (i < len && oneChar != 0);

	return i;
}
/*
	Tang bien PC
*/
void AdvanceProgramCounter()
{
	int pc;
	pc = machine->ReadRegister(PCReg);
	machine->WriteRegister(PrevPCReg, pc);
	pc = machine->ReadRegister(NextPCReg);
	machine->WriteRegister(PCReg, pc);
	pc += 4;
	machine->WriteRegister(NextPCReg, pc);
}

void doCreate()
{
	char *name; 	// Ten file can tao
	int virtAddr; 	// Dia chi cua chuoi (user) (register 4)
	int kq; 	// Ket qua tra ve cho nguoi dung (register 2)

	// Doc gia tri tu cac thanh ghi
	virtAddr = machine->ReadRegister(4);
	name = User2System(virtAddr, MAXFILELENGTH); 

	DEBUG('c', "doCreate()\n");	

	// Neu chuoi name = NULL hay chieu dai ten file qua dai 
	// thi tra ve loi (-1)
	if (name == NULL || strlen(name) <= 0 || strlen(name) > MAXFILELENGTH)
		kq = -1;
	else
		kq = currentThread->glTab->fdCreate(name);

	if (name != NULL)
		delete []name;

	machine->WriteRegister(2, kq);
	AdvanceProgramCounter();
}

void doOpen()
{
	char *name; 	// Ten file can tao
	int virtAddr; 	// Dia chi cua chuoi (user) (register 4)
	int filetype; 	// Loai file (register 5)
	int kq; 	// Ket qua tra ve cho nguoi dung (register 2)
	
	DEBUG('t', "doOpen()\n");

	// Doc gia tri tu cac thanh ghi
	virtAddr = machine->ReadRegister(4);
	filetype = machine->ReadRegister(5); 
	name = User2System(virtAddr, MAXFILELENGTH); 
		
	// Neu chuoi name = NULL hay chieu dai ten file qua dai 
	// thi tra ve loi (-1)
	if (name == NULL || strlen(name) <= 0 || strlen(name) > MAXFILELENGTH)
		kq = -1;
	else
	{		
		DEBUG('t', "doOpen(%s, %d)\n", name, filetype);
		kq = currentThread->glTab->fdOpen(name, filetype);
		// Truyen sai tham so
		if (kq == -2)
		{
			kq = -1;
			printf("Loi mo file: khong co filetype nay\n");
		}
	}

	if (name != NULL)
		delete []name;
	
	machine->WriteRegister(2, kq);
	AdvanceProgramCounter();
}

void doWrite()
{
	char *buffer = NULL;	// Chuoi can xuat
	int charcount; 		// Chieu dai toi da cua chuoi (register 5)
	OpenFileId id; 		// id cua file can ghi (register 6)
	int virtAddr; 		// Dia chi cua chuoi (user) (register 4)
	int kq = -1; 		// Gia tri tra ve cho nguoi dung (register 2)
 
	// Doc gia tri tu cac thanh ghi
	virtAddr = machine->ReadRegister(4); 
	charcount = machine->ReadRegister(5);
	id = machine->ReadRegister(6);

	DEBUG('p', "charcount: %d, id: %d, %d", charcount, id, virtAddr);

	if (charcount > 0)
	{
		buffer = User2System(virtAddr, charcount);
		DEBUG('p', "buffer: s\n", buffer);

		// Neu co chuoi (system) ung voi virtAddr thi xu ly
		if (buffer != NULL)
		{
			charcount = strlen(buffer);

			kq = currentThread->glTab->fdWrite(buffer, charcount, id);
			delete []buffer;
		}
	}
	
	machine->WriteRegister(2, kq);
	AdvanceProgramCounter();
}

void doRead()
{
	char *buffer = NULL;	// Chuoi ket qua (System)
	int charcount;		// Chieu dai toi da cua chuoi (register 5)
	OpenFileId id;		// id cua file can doc (register 6)
	int virtAddr; 		// Dia chi cua chuoi (user) (register 4)
	int kq = -1; 		// Gia tri tra ve cho nguoi dung (register 2)
	
	// Doc gia tri tu cac thanh ghi
	virtAddr = machine->ReadRegister(4);
	charcount = machine->ReadRegister(5);
	id = machine->ReadRegister(6);
	
	if (charcount > 0)
	{	
		buffer = new char[charcount + 1];
		
		// Neu cap phat thanh cong thi xu ly
		if (buffer != NULL)
		{
			charcount = currentThread->glTab->fdRead(buffer, charcount, id);
		
			// Neu doc thanh cong thi copy chuoi vua doc ve cho user
			if (charcount > 0)			
				kq = System2User(virtAddr, charcount, buffer);
			else	// Co loi
				kq = charcount;

			delete []buffer;
		}
	}
	
	machine->WriteRegister(2, kq);
	AdvanceProgramCounter();
}

void doClose()
{
	OpenFileId id;	// id cua file can dong (register 4)
	
	id = machine->ReadRegister(4);

	DEBUG('k', "doClose %d\n", id);

	machine->WriteRegister(2, currentThread->glTab->fdClose(id));
	AdvanceProgramCounter();
}

void doSeek()
{
	int pos;	// Vi tri di chuyen con tro toi (register 4)
	int id;		// id cua file (register 5)

	pos = machine->ReadRegister(4);
	id = machine->ReadRegister(5);
	
	DEBUG('k', "doSeek id:%d, pos: %d\n", id, pos);
	if (id == 0 || id == 1)
	{
		printf("Khong the thuc hien ham Seek tren Console\n");
		machine->WriteRegister(2, -1); 
	}
	else
		machine->WriteRegister(2, currentThread->glTab->fdSeek(pos, id));
	AdvanceProgramCounter();
}
