#ifndef _CFDRW_H
#define _CFDRW_H

#include "syscall.h"
#include "CFDBase.h"
#include "openfile.h"

/*
	CFDCout dung de thuc hien cac thao tac doc va ghi file
*/
class CFDRW: public CFDBase
{
private:
	OpenFile *m_File;	// Chua thong tin cua file de thuc hien
				// cac thao tac doc, ghi tren file
public:
	CFDRW();
	CFDRW(char *name);
	virtual ~CFDRW();

	int fCreate(char *name);		// Tao file
	int fOpen(char *name);			// Mo file
	int fWrite(char *buffer, int charcount);// Ghi du lieu len file
	int fRead(char *buffer, int charcount); // Doc du lieu tu file
	int fClose();				// Dong file
	int fSeek(int pos);			// Di chuyen con tro cua file

};

#endif
