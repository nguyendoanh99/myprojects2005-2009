#ifndef _CFDBASE_H
#define _CFDBASE_H

#include "syscall.h"

/*
	CFDBase la mot lop Interface, chi chua cac ham thuan ao
	de cac lop con no ke thua, cac lop con cua no la:
		CFDCin
		CFDCout
		CFDRW
		CFDRo
*/
class CFDBase
{
public:
	virtual ~CFDBase();

	virtual int fCreate(char *name) = 0;
	virtual OpenFileId fOpen(char *name) = 0;
	virtual int fWrite(char *buffer, int charcount) = 0;
	virtual int fRead(char *buffer, int charcount) = 0;
	virtual int fClose() = 0;
	virtual int fSeek(int pos) = 0;
};

#endif
