// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"
#include "SCHandle.h"
//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------

void
ExceptionHandler(ExceptionType which)
{
    int type = machine->ReadRegister(2);

    switch (which)
    {
	case NoException:
		printf("NoException");
		interrupt->Halt();
		return;
	case PageFaultException:
		printf("PageFaultException");
		interrupt->Halt();
		break;
	case ReadOnlyException:
		printf("ReadOnlyException");
		interrupt->Halt();
		break;
	case BusErrorException:
		printf("BusErrorException");
		interrupt->Halt();
		break;
	case AddressErrorException:
		printf("AddressErrorException");
		interrupt->Halt();
		break;
	case OverflowException:
		printf("OverflowException");
		interrupt->Halt();
		break;
	case IllegalInstrException:
		printf("IllegalInstrException");
		interrupt->Halt();
		break;
	case NumExceptionTypes:
		printf("NumExceptionTypes");
		interrupt->Halt();
		break;

	case SyscallException:		
		switch (type)
		{
		case SC_Create:
			DEBUG('k', "SC_Create");
			doCreate();
			break;
		case SC_Open:
			DEBUG('k', "SC_Open");
			doOpen();
			break;
		case SC_Read:		
			DEBUG('k', "SC_Read");
			doRead();
			break;
		case SC_Write:
			DEBUG('k', "SC_Write");
			doWrite();
			break;
		case SC_Close:
			DEBUG('k', "SC_Close");
			doClose();
			break;
		case SC_Seek:			
			DEBUG('k', "SC_Seek");
			doSeek();
			break;
		case SC_Halt:
			DEBUG('k', "SC_Halt");
			interrupt->Halt();
			break;
		case SC_Exit:
			DEBUG('k', "SC_Exit");
			interrupt->Halt();
			break;		
		case SC_Exec:
			DEBUG('k', "SC_Exec");
			interrupt->Halt();
			break;
		case SC_Join:
			DEBUG('k', "SC_Join");
			interrupt->Halt();
			break;
		case SC_Fork:
			DEBUG('k', "SC_Fork");
			interrupt->Halt();
			break;
		case SC_Yield:
			DEBUG('k', "SC_Yield");
			interrupt->Halt();
			break;
		}
		break;
    }
}
