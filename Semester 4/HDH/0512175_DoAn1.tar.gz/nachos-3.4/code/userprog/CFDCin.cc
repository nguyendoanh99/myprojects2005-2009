#include "CFDCin.h"
#include "system.h"

CFDCin::CFDCin()
{
//	if (glSynchConsole  == NULL)
//		glSynchConsole = new SynchConsole;
}

CFDCin::~CFDCin()
{
//	if(glSynchConsole != NULL)
//		delete glSynchConsole;
//	glSynchConsole = NULL;
}

int CFDCin::fRead(char *buffer, int charcount)
{
	int Kq;
	Kq = glSynchConsole->Read(buffer, charcount);

	if(Kq == -1)
		return -2; 
	return Kq; // So ki tu thuc su doc duoc
}

int CFDCin::fWrite(char *buffer, int charcount)
{
	return -1;
}

int CFDCin::fCreate(char *name)
{
	return -1;
}

OpenFileId CFDCin::fOpen(char *name)
{
	return -1;
}

int CFDCin::fClose()
{
	return -1;
}

int CFDCin::fSeek(int pos)
{
	return -1;
}
