#ifndef _SCHANDLE_H
#define _SCHANDLE_H
#include "syscall.h"

char *User2System(int virtAddr, int limit);
int System2User(int virtAddr, int len, char *buffer);
void AdvanceProgramCounter(); // Tang bien PC

void doCreate();// Ham xu ly cua system call SC_Create
void doOpen();	// Ham xu ly cua system call SC_Open
void doWrite();	// Ham xu ly cua system call SC_Write
void doRead();	// Ham xu ly cua system call SC_Read
void doClose();	// Ham xu ly cua system call SC_Close
void doSeek();	// Ham xu ly cua system call SC_Seek

#endif
