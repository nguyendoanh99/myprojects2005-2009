#include "syscall.h"

int main()
{
	char f[256], g[256];
	OpenFileId id1, id2;
	char t[2];

	Write("\t\tCHUONG TRINH COPY\n", 100, 1);
	Write("File nguon (phai ton tai):", 100, 1);
	Read(f, 255, 0);
	
	Write("File dich :", 100, 1);
	Read(g, 255, 0);
	// Neu file chua co thi tao ra
	CreateFile(g);

	id1 = Open(f, ReadOnly);
	id2 = Open(g, ReadWrite);
	if (id1 != -1 && id2 != -1)
	{
		while (Read(t, 1, id1) != -2)
			if (Write(t, 1, id2) != 1)
			{
				Write("Khong the ghi file duoc", 100, 1);
				Halt();
			}
	}
	else
	{
		Write("Khong the mo file duoc", 100, 1);
	}
}
