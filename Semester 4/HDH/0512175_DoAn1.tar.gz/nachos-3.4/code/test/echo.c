#include "syscall.h"

int main()
{
	char s[255];
	Write("Nhap vao 1 chuoi: ", 100, 1);
	Read(s, 254, 0);
	Write("Chuoi vua nhap: \n", 100, 1);
	Write(s, 254, 1);
	return 0;
}
