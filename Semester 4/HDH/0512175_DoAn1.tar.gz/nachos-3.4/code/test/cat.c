#include "syscall.h"

int main()
{
	OpenFileId id;
	char filename[255];
	char t[2];
	Write("Nhap ten file: ", 100, 1);
	Read(filename, 254, 0);
	
	id = Open(filename, ReadOnly);
	if (id != -1)
	{
		Write("Noi dung cua file:\n", 100, 1);
		while (Read(t, 1, id) != -2)
			Write(t, 1, 1);
	}
	else
		Write("Khong mo duoc file", 100, 1);

	return 0;
}
