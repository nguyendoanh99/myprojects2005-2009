#include "syscall.h"
void main()
{
	Write("\t\tCAC LENH CO BAN CO THE SU DUNG\n", 100, 1);
	Write("\tint CreateFile(char *name)\n", 100, 1);
	Write("\tOpenFileId Open(char *name, int filetype)\n", 100, 1);
	Write("\tint Write(char *buffer, int charcount, OpenFileId id)\n", 100, 1);
	Write("\tint Read(char *buffer, int charcount, OpenFileId id)\n", 100, 1);
	Write("\tint Close(OpenFileId id)\n", 100, 1);
	Write("\tint Seek(int pos, OpenFileId id)\n", 100, 1);
	Halt();
}
