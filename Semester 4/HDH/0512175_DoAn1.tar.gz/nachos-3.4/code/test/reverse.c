#include "syscall.h"

int main()
{
	char f[256], g[256];
	OpenFileId id1, id2;
	char t[2];
	int len;
	int i;

	Write("\t\tCHUONG TRINH REVERSE\n", 100, 1);
	Write("File nguon (phai ton tai):", 100, 1);
	Read(f, 255, 0);
	
	Write("File dich :", 100, 1);
	Read(g, 255, 0);
	// Neu file chua co thi tao ra
	CreateFile(g);

	id1 = Open(f, ReadOnly);
	id2 = Open(g, ReadWrite);
	if (id1 != -1 && id2 != -1)
	{
		len = Seek(-1, id1);
		Seek(0, id2);	
		for (i = len - 1; i >= 0; --i)
		{
			Seek(i, id1);
			Read(t, 1, id1);
			Write(t, 1, 1);
			if (Write(t, 1, id2) != 1)
			{
				Write("Khong the ghi file duoc", 100, 1);
				break;
			}
		}
	}
	else
	{
		Write("Khong the mo file duoc", 100, 1);
	}
}
