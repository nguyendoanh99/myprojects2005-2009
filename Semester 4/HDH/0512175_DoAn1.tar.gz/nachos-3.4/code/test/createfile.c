#include "syscall.h"

int main()
{
	char name[256];
	Write("Nhap ten file muon tao:", 100, 1);
	Read(name, 255, 0);
	
	if (CreateFile(name) == 0)
	{
		Write("\nTao file thanh cong.\n", 100, 1);
	}
	else
		Write("\nTao file that bai.\n", 100, 1);

	Halt();
}
