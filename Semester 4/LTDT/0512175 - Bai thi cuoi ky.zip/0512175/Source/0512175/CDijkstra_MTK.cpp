#include "CDijkstra_MTK.h"
#include "fstream.h"
#include "iomanip.h"
int CDijkstra_MTK::Input(char *filename)
{
	ifstream f;
	f.open(filename, ios::nocreate | ios::in);
	if (!f)
		return 0;

	int n, m;
	int x, y, w;

	f >> n >> m >> m_k;

	for (int j = 0; j < m_k; ++j)
		f >> m_DaiLy[j];
	int **A = new int*[n + 1];
	for (int i = 1; i <= n; ++i)
		A[i] = new int[n + 1];

	for (i = 0; i < m; ++i)
	{
		f >> x >> y >> w;
		A[x][y] = w;
		A[y][x] = w;
	}

	Tao(n, A);
	for (i = 1; i <= n; ++i)
		delete []A[i];
	delete []A;
	
//	m_fTongTrongSo = Run(5, 3);	
	return 1;
}

void SapXep(float *A, int n)
{
	for (int i = 0; i < n; ++i)
		for (int j = i + 1; j < n; ++j)
			if (A[i] > A[j])
			{
				float temp = A[i];
				A[i] = A[j];
				A[j] = temp;
			}
}
int CDijkstra_MTK::Output(char *filename)
{
	ofstream f;
	f.open(filename);
	
	if (!f)
		return 0;

	int max = (m_k * (m_k + 1)) / 2;
	float *A = new float[max];
	float temp;
	int dem = 0;
	for (int i = 0; i < m_k; ++i)
	{
		for (int j = i + 1; j < m_k; ++j)
		{
			temp = Run(m_DaiLy[i], m_DaiLy[j]);			
			if (temp != 0)
			{
				A[dem] = temp;
				dem++;
			}
		}
	}
	
	SapXep(A, dem);

	float kq = 0;
	for (int j = 0; j < m_k - 1; ++j)
		kq += A[j];

	f << setiosflags(ios::fixed);
	f << setprecision(0) <<kq;
	delete A;
	return 1;
}

int CDijkstra_MTK::nVer()
{
	return LaySoDinh();
}

float CDijkstra_MTK::Distance(int i, int j)
{
	return (float) LayCanhNoi(i, j);
}

CDijkstra_MTK::~CDijkstra_MTK()
{
}
